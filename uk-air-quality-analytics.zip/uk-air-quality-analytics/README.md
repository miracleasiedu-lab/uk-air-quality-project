# UK Air Quality Monitoring & Pollution Analytics Dashboard

An end-to-end Python analytics project built on **real DEFRA UK-AIR monitoring data** from the Automatic Urban and Rural Network (AURN). It covers London and major UK cities. The project downloads historical and latest hourly readings, validates and cleans them, engineers time and health-threshold features, runs a structured analysis (10 KPIs and 30 univariate, bivariate and multivariate analyses, plus time-series, hotspot and anomaly analyses), and serves the results in an interactive Streamlit dashboard.

**Domain:** Environmental / public-health analytics
**End user:** Environmental Monitoring / Public Health Team
**Stack:** Python · Pandas · NumPy · Requests · pyreadr · SciPy · Plotly · Matplotlib · Streamlit

> **No results are hard-coded.** All findings, recommendations and the conclusion in `reports/key_findings.md` are generated from the data you download. If a pollutant or site is not available, the project says so instead of filling the gap.

---

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python run_pipeline.py            # download DEFRA data → clean → features → report
streamlit run dashboard/app.py    # open the dashboard
jupyter lab notebooks/air_quality_analysis.ipynb
pytest -q                         # pipeline tests (synthetic fixture, offline)
```

Useful options:

```bash
python -m src.extract --discover Manchester        # list real AURN site codes for a town
python run_pipeline.py --sites MY1 KC1 MAN3 --years 2024 2025 2026
python run_pipeline.py --skip-extract              # reprocess without downloading
```

The current year is always re-downloaded, so re-running the pipeline (or pressing **Refresh latest DEFRA readings** in the dashboard) picks up the newest available hours. Earlier years are cached in `data/raw/cache/`.

## Workflow

```
DEFRA UK-AIR ─► extract.py ─► raw validation ─► exploration ─► data-quality assessment
   ─► clean.py ─► features.py ─► station analysis ─► 10 KPIs ─► 10 univariate
   ─► 10 bivariate ─► 10 multivariate ─► time series ─► hotspots ─► anomalies
   ─► dashboard ─► insights ─► recommendations ─► limitations ─► conclusion
```

## Project structure

```
├── run_pipeline.py              orchestrates the full pipeline
├── src/
│   ├── config.py                sources, candidate sites, units, thresholds, rules
│   ├── extract.py               data-extraction script (DEFRA RData + CSV fallback)
│   ├── quality.py               raw validation + data-quality assessment
│   ├── clean.py                 cleaning pipeline (audited, no imputation)
│   ├── features.py              feature engineering (calendar, rolling, DAQI, WHO)
│   ├── analysis.py              KPIs, 30 analyses, trends, hotspots, anomalies
│   └── report.py                data-driven findings / recommendations / conclusion
├── dashboard/app.py             Streamlit dashboard
├── notebooks/air_quality_analysis.ipynb
├── docs/
│   ├── methodology.md           exact datasets, units, timestamps, thresholds, methods
│   └── data_dictionary.md
├── data/raw/                    downloads + provenance manifest (created on run)
├── data/processed/              clean analytical datasets + QA files (created on run)
├── reports/                     key_findings.md + tables/ (created on run)
└── tests/test_pipeline.py
```

## Data

| | |
|---|---|
| Source | DEFRA UK-AIR, AURN hourly site files (`uk-air.defra.gov.uk/openair/R_data/`), with the UK-AIR pre-formatted CSV files as a fallback |
| Pollutants | PM2.5, PM10, NO₂, O₃, SO₂, CO, wherever each site measures them |
| Units | µg/m³ (CO in mg/m³) |
| Weather context | Modelled wind speed, wind direction and temperature supplied in the same DEFRA files |
| Coverage | Two previous full years plus the current year to date (configurable) |
| Stations | Candidate London and major-city AURN sites, each validated against live DEFRA metadata |
| Licence | © Crown copyright Defra via uk-air.defra.gov.uk, licensed under the Open Government Licence |

Full detail, including the exact URLs, the hour-beginning vs hour-ending conversion, DAQI and WHO thresholds, and capture rules, is in [`docs/methodology.md`](docs/methodology.md). The files actually retrieved on each run are listed in `data/raw/extraction_manifest.json`.

## KPIs

1. Average PM2.5
2. Average PM10
3. Average NO₂
4. Average O₃
5. Maximum hourly PM2.5 (with site and time)
6. Maximum hourly NO₂ (with site and time)
7. Number of stations analysed
8. Number and percentage of high-pollution site-hours (DAQI *Moderate* or above, on each pollutant's official averaging period)
9. Location with the highest average for a chosen pollutant
10. Month with the highest average for a chosen pollutant

## Analyses

**Univariate (U1–U10):** distributions of PM2.5, PM10, NO₂, O₃, SO₂ and CO · DAQI band frequency · data capture · daily PM2.5 vs the WHO guideline · daily NO₂ peaks

**Bivariate (B1–B10):** PM2.5 vs PM10 · NO₂ vs O₃ · NO₂ by hour · PM2.5 by month · weekday vs weekend (Mann–Whitney) · site environment · NO₂ vs wind · O₃ vs temperature · NO₂ by site · PM2.5 by season

**Multivariate (M1–M10):** correlation matrix · site × month · site × hour · site × season × pollutant · weekday × hour · standardised site profiles · PCA · wind × hour × NO₂ · environment × season × pollutant · temperature × season × O₃

**Advanced:**
- 30-day rolling trends
- Theil–Sen trend on de-seasonalised monthly means
- Composite hotspot score with map
- Robust anomaly detection that separates regional episodes from local spikes
- Latest readings with data freshness

## Dashboard

The dashboard has seven tabs:

- **Overview:** KPI cards and the latest readings, coloured by DAQI band
- **Trends:** the selected pollutant, plus PM2.5, PM10, NO₂ and O₃ histories and monthly means
- **Locations:** station ranking and a station × month heatmap
- **Hotspots:** map and scoring table
- **Patterns:** hour, weekday, season and month profiles, and correlations
- **Anomalies**
- **Data quality:** validation checks, completeness, cleaning log and download provenance

Filters cover stations, pollutant and date range. A refresh button pulls the latest DEFRA readings.

## Findings, recommendations, limitations, conclusion

After `python run_pipeline.py`, see **`reports/key_findings.md`**. The same content appears at the end of the notebook. Recommendations are rule-based: each one appears only when the data support it, and the evidence is quoted alongside it. Known methodological limitations are listed in the report and in `docs/methodology.md`.

## Testing

`pytest` runs the whole pipeline offline against a **synthetic fixture** that is generated in a temporary folder. It checks that the code works: duplicate handling, removal of negative and implausible values, the hour-ending timestamp conversion, the NOx vs NO₂ column disambiguation, unknown-site handling and report generation. Fixture data never reaches `data/` or `reports/`.
