"""
UK Air Quality Monitoring Dashboard (Streamlit)

    streamlit run dashboard/app.py

Reads the processed datasets written by run_pipeline.py. Every number shown is
computed live from those files for the current filter selection.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import analysis as A  # noqa: E402
from src import config as C  # noqa: E402
from src.features import DAY_ORDER, MONTH_ORDER, SEASON_ORDER, pollutants_in  # noqa: E402

BAND_COLOURS = {"Low": "#4f9d69", "Moderate": "#e9b44c", "High": "#d1495b", "Very High": "#6a1b4d", "—": "#cccccc"}

st.set_page_config(page_title="UK Air Quality Monitor", page_icon="🌫️", layout="wide")
st.markdown("""
<style>
  .block-container {padding-top: 1.6rem; max-width: 1400px;}
  [data-testid="stMetricValue"] {font-size: 1.35rem;}
  [data-testid="stMetricLabel"] p {font-size: .82rem; color: #4a5560;}
  .src {font-size: .78rem; color: #6b7680;}
</style>""", unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------
@st.cache_data(show_spinner="Loading processed DEFRA data…")
def load():
    p = C.DATA_PROCESSED
    hourly = pd.read_parquet(p / "hourly_clean.parquet")
    daily = pd.read_parquet(p / "daily_clean.parquet")
    dq = pd.read_csv(p / "data_quality.csv") if (p / "data_quality.csv").exists() else pd.DataFrame()
    val = pd.read_csv(p / "raw_validation.csv") if (p / "raw_validation.csv").exists() else pd.DataFrame()
    clog = pd.read_csv(p / "cleaning_log.csv") if (p / "cleaning_log.csv").exists() else pd.DataFrame()
    man_path = C.DATA_RAW / "extraction_manifest.json"
    manifest = json.loads(man_path.read_text()) if man_path.exists() else {}
    return hourly, daily, dq, val, clog, manifest


if not (C.DATA_PROCESSED / "hourly_clean.parquet").exists():
    st.title("UK Air Quality Monitor")
    st.warning("No processed data yet. Run `python run_pipeline.py` to download DEFRA UK-AIR data, "
               "or use the button below.")
    if st.button("Download and process DEFRA data now"):
        with st.spinner("Running pipeline (a few minutes on first run)…"):
            r = subprocess.run([sys.executable, "run_pipeline.py"], cwd=ROOT, capture_output=True, text=True)
        st.code(r.stdout[-3000:] + r.stderr[-3000:])
        st.rerun()
    st.stop()

hourly, daily, dq, val, clog, manifest = load()
POLS = pollutants_in(hourly)

# --------------------------------------------------------------------------
# Sidebar filters
# --------------------------------------------------------------------------
with st.sidebar:
    st.header("Filters")
    sites_all = (hourly[["site_name", "city"]].drop_duplicates().sort_values(["city", "site_name"]))
    site_sel = st.multiselect("Monitoring stations", sites_all["site_name"].tolist(),
                              default=sites_all["site_name"].tolist(),
                              format_func=lambda s: f"{s} ({sites_all.set_index('site_name').city[s]})")
    pol = st.selectbox("Pollutant", POLS, index=POLS.index("no2") if "no2" in POLS else 0, format_func=A.name)
    dmin, dmax = hourly["date_local"].min().date(), hourly["date_local"].max().date()
    dr = st.date_input("Date range", (dmin, dmax), min_value=dmin, max_value=dmax)
    d0, d1 = (dr if isinstance(dr, tuple) and len(dr) == 2 else (dmin, dmax))
    st.divider()
    if st.button("Refresh latest DEFRA readings"):
        with st.spinner("Re-downloading current-year files and rebuilding…"):
            r = subprocess.run([sys.executable, "run_pipeline.py"], cwd=ROOT, capture_output=True, text=True)
        if r.returncode == 0:
            st.cache_data.clear()
            st.rerun()
        else:
            st.error("Refresh failed – details below.")
            st.code(r.stderr[-3000:])
    st.markdown(f"<p class='src'>Source: DEFRA UK-AIR, AURN network. {C.ATTRIBUTION}</p>",
                unsafe_allow_html=True)

if not site_sel:
    st.info("Select at least one monitoring station.")
    st.stop()

h = hourly[hourly["site_name"].isin(site_sel)
           & hourly["date_local"].between(pd.Timestamp(d0), pd.Timestamp(d1))]
d = daily[daily["site_name"].isin(site_sel)
          & pd.to_datetime(daily["date_local"]).between(pd.Timestamp(d0), pd.Timestamp(d1))]
if h[POLS].notna().sum().sum() == 0:
    st.info("No valid readings for this selection.")
    st.stop()

u = A.unit(pol)
st.title("UK Air Quality Monitor")
st.caption(f"{len(site_sel)} stations · {d0:%d %b %Y} – {d1:%d %b %Y} · times in UK local time · "
           "DAQI = UK Daily Air Quality Index")

tabs = st.tabs(["Overview", "Trends", "Locations", "Hotspots", "Patterns", "Anomalies", "Data quality"])

# --------------------------------------------------------------------------
# Overview
# --------------------------------------------------------------------------
with tabs[0]:
    k = A.kpis(h, site_pollutant=pol, month_pollutant=pol)
    for row in (k.iloc[:5], k.iloc[5:]):
        cols = st.columns(len(row))
        for c, r in zip(cols, row.itertuples()):
            c.metric(r.name, r.value, help=r.detail)
    st.subheader("Latest available readings")
    latest = A.latest_readings(hourly[hourly["site_name"].isin(site_sel)])
    if len(latest):
        st.caption(f"Most recent hour in the data: {latest['hour_beginning_uk'].max()} (UK time). "
                   "Current-year data are provisional (unratified).")
        view = latest[latest["pollutant"] == A.name(pol)].sort_values("value", ascending=False)
        st.dataframe(view.style.apply(
            lambda r: [f"background-color: {BAND_COLOURS.get(r.daqi_band, '#fff')}33"] * len(r), axis=1),
            hide_index=True, width="stretch")
        with st.expander("All pollutants"):
            st.dataframe(latest, hide_index=True, width="stretch")

# --------------------------------------------------------------------------
# Trends
# --------------------------------------------------------------------------
with tabs[1]:
    st.plotly_chart(A.daily_trend_fig(d, pol), width="stretch", key="trend_selected")
    m = (d.groupby("year_month")[f"{pol}_mean"].mean().reset_index())
    st.plotly_chart(px.bar(m, x="year_month", y=f"{pol}_mean", template=A.TEMPLATE,
                           title=f"Monthly mean {A.name(pol)} (selected stations)",
                           labels={f"{pol}_mean": u, "year_month": ""}), width="stretch")
    st.subheader("Historical trends – core pollutants")
    core = [p for p in ("pm25", "pm10", "no2", "o3") if p in POLS]
    for i in range(0, len(core), 2):
        cols = st.columns(2)
        for c, p in zip(cols, core[i:i + 2]):
            c.plotly_chart(A.daily_trend_fig(d, p), width="stretch", key=f"trend_core_{p}")
    tr = A.trends(d)
    st.subheader("Indicative trend")
    st.caption(tr.finding)
    if tr.fig:
        st.plotly_chart(tr.fig, width="stretch")

# --------------------------------------------------------------------------
# Locations
# --------------------------------------------------------------------------
with tabs[2]:
    s = (h.groupby(["site_name", "city", "location_type"])[pol].agg(["mean", "max", "count"])
         .dropna().sort_values("mean", ascending=False).reset_index())
    fig = px.bar(s, x="mean", y="site_name", color="location_type", orientation="h", template=A.TEMPLATE,
                 title=f"Mean {A.name(pol)} by station", labels={"mean": u, "site_name": ""},
                 height=max(380, 30 * len(s)))
    fig.update_yaxes(categoryorder="total ascending")
    st.plotly_chart(fig, width="stretch")
    hm = h.pivot_table(index="site_name", columns="year_month", values=pol, aggfunc="mean")
    st.plotly_chart(px.imshow(hm, aspect="auto", color_continuous_scale="YlOrRd", template=A.TEMPLATE,
                              title=f"{A.name(pol)}: station × month", labels={"color": u}),
                    width="stretch")
    st.dataframe(s.round(1), hide_index=True, width="stretch")

# --------------------------------------------------------------------------
# Hotspots
# --------------------------------------------------------------------------
with tabs[3]:
    hs = A.hotspots(h, d)
    st.caption(hs.finding + " Score = average percentile rank across PM2.5, PM10 and NO₂ means "
               "(relative to the selected stations).")
    if hs.fig:
        st.plotly_chart(hs.fig, width="stretch")
    st.dataframe(hs.table, hide_index=True, width="stretch")

# --------------------------------------------------------------------------
# Patterns
# --------------------------------------------------------------------------
with tabs[4]:
    c1, c2 = st.columns(2)
    prof = h.groupby(["hour", "day_type"])[pol].mean().reset_index()
    c1.plotly_chart(px.line(prof, x="hour", y=pol, color="day_type", markers=True, template=A.TEMPLATE,
                            title=f"{A.name(pol)} by hour: weekday vs weekend", labels={pol: u}),
                    width="stretch")
    sea = d.dropna(subset=[f"{pol}_mean"])
    c2.plotly_chart(px.box(sea, x="season", y=f"{pol}_mean", category_orders={"season": SEASON_ORDER},
                           template=A.TEMPLATE, title=f"Daily-mean {A.name(pol)} by season",
                           labels={f"{pol}_mean": u}), width="stretch")
    wk = h.pivot_table(index="day_of_week", columns="hour", values=pol, aggfunc="mean",
                       observed=True).reindex(DAY_ORDER)
    st.plotly_chart(px.imshow(wk, aspect="auto", color_continuous_scale="YlOrRd", template=A.TEMPLATE,
                              title=f"{A.name(pol)}: day of week × hour", labels={"color": u}),
                    width="stretch")
    mo = h.groupby("month_name", observed=True)[pol].mean().reindex(MONTH_ORDER).dropna().reset_index()
    st.plotly_chart(px.bar(mo, x="month_name", y=pol, template=A.TEMPLATE,
                           title=f"{A.name(pol)} by calendar month", labels={pol: u, "month_name": ""}),
                    width="stretch")
    corr_cols = POLS + [m for m in ("ws", "temp") if m in h and h[m].notna().any()]
    cm = h[corr_cols].corr(method="spearman").round(2)
    st.plotly_chart(px.imshow(cm, text_auto=True, zmin=-1, zmax=1, color_continuous_scale="RdBu_r",
                              template=A.TEMPLATE, title="Spearman correlation (hourly)"),
                    width="stretch")

# --------------------------------------------------------------------------
# Anomalies
# --------------------------------------------------------------------------
with tabs[5]:
    an = A.anomalies(d)
    st.caption(an.finding + " Method: daily mean vs centred 30-day rolling median, robust z > 3.5.")
    if an.fig:
        st.plotly_chart(an.fig, width="stretch")
    if len(an.table):
        st.dataframe(an.table, hide_index=True, width="stretch")

# --------------------------------------------------------------------------
# Data quality & provenance
# --------------------------------------------------------------------------
with tabs[6]:
    st.subheader("Raw validation checks")
    st.dataframe(val, hide_index=True, width="stretch")
    st.subheader("Completeness by station and pollutant")
    st.dataframe(dq, hide_index=True, width="stretch")
    st.subheader("Cleaning log")
    st.dataframe(clog, hide_index=True, width="stretch")
    if manifest:
        st.subheader("Extraction provenance")
        st.write(f"Run at {manifest.get('run_at', '')} · sites not found in DEFRA metadata: "
                 f"{manifest.get('sites_not_in_metadata') or 'none'}")
        st.dataframe(pd.DataFrame(manifest.get("files", [])).reindex(
            columns=["site", "year", "status", "source", "rows", "first", "last", "url"]),
            hide_index=True, width="stretch")
