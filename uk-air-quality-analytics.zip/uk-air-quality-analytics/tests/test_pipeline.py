"""
Pipeline tests.

IMPORTANT: the data generated here is a SYNTHETIC TEST FIXTURE used only to
check that the code runs and that the cleaning rules behave as documented.
It is written to a temporary directory and is never used for any finding.

    pytest -q
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src import config as C
from src import extract


def _fake_site_year(code: str, year: int, rng) -> pd.DataFrame:
    idx = pd.date_range(f"{year}-01-01", f"{year}-12-31 23:00", freq="h", tz="UTC")
    n = len(idx)
    hour = idx.hour.to_numpy()
    df = pd.DataFrame({
        "site": f"Test {code}", "code": code, "date": idx.tz_localize(None),
        "NO2": rng.gamma(3, 10, n) + 10 * np.isin(hour, [7, 8, 17, 18]),
        "O3": rng.gamma(4, 12, n),
        "PM10": rng.gamma(3, 6, n),
        "PM2.5": rng.gamma(2, 4, n),
        "ws": rng.gamma(2, 2, n), "wd": rng.uniform(0, 360, n), "temp": rng.normal(11, 6, n),
    })
    gaps = rng.random(n) < 0.05
    df.loc[gaps, "NO2"] = np.nan
    df.loc[5, "PM10"] = -3          # negative → must be removed
    df.loc[6, "PM2.5"] = 5000       # implausible → must be removed
    return df


@pytest.fixture()
def fake_defra(tmp_path, monkeypatch):
    pyreadr = pytest.importorskip("pyreadr")
    rng = np.random.default_rng(0)
    files = tmp_path / "fixtures"
    files.mkdir()
    sites = {"AAA": "Urban Traffic", "BBB": "Urban Background", "CCC": "Urban Background"}
    meta = pd.DataFrame({"site_id": list(sites), "site_name": [f"Test {s}" for s in sites],
                         "location_type": list(sites.values()),
                         "latitude": [51.5, 53.5, 55.9], "longitude": [-0.1, -2.2, -4.2]})
    pyreadr.write_rdata(str(files / "AURN_metadata.RData"), meta, df_name="meta")
    for s in sites:
        for y in (2024, 2025):
            pyreadr.write_rdata(str(files / f"{s}_{y}.RData"), _fake_site_year(s, y, rng), df_name=f"{s}{y}")

    def fake_download(url, dest, refresh):
        src = files / url.rsplit("/", 1)[-1].split("?")[0]
        if not src.exists():
            raise extract.NotFound(url)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(src.read_bytes())
        return dest

    for attr, sub in (("DATA_RAW", "raw"), ("DATA_PROCESSED", "processed"), ("REPORTS", "reports")):
        monkeypatch.setattr(C, attr, tmp_path / sub)
    monkeypatch.setattr(extract, "CACHE", tmp_path / "raw" / "cache")
    monkeypatch.setattr(extract, "_download", fake_download)
    monkeypatch.setattr(C, "CANDIDATE_SITES", {s: f"City {s}" for s in sites})
    return tmp_path


def test_end_to_end(fake_defra, monkeypatch):
    import run_pipeline
    monkeypatch.setattr("sys.argv", ["run_pipeline.py", "--sites", "AAA", "BBB", "CCC", "ZZZ",
                                     "--years", "2024", "2025"])
    run_pipeline.main()

    hourly = pd.read_parquet(fake_defra / "processed" / "hourly_clean.parquet")
    daily = pd.read_parquet(fake_defra / "processed" / "daily_clean.parquet")
    assert hourly["site_code"].nunique() == 3                       # ZZZ dropped
    assert (hourly["pm10"].dropna() >= 0).all()                      # negatives removed
    assert hourly["pm25"].max() <= C.PLAUSIBILITY_MAX["pm25"]        # cap applied
    assert {"season", "day_type", "pm25_24h", "o3_8h", "high_pollution"} <= set(hourly.columns)
    assert daily["no2_n"].max() <= 25                                # ≤ 24 h (+1 on BST change day)
    assert (fake_defra / "reports" / "key_findings.md").exists()
    log = pd.read_csv(fake_defra / "processed" / "cleaning_log.csv")
    assert log.loc[log.step.str.startswith("Negative pm10"), "values_affected"].sum() >= 6


def test_csv_parser_hour_ending_conversion():
    text = ("Hourly data from DEFRA\nSite Name,Test\n\n"
            "Date,time,Nitrogen dioxide,status,unit,Nitrogen oxides as nitrogen dioxide,status,unit,"
            "PM2.5 particulate matter (Hourly measured),status,unit\n"
            "01-01-2025,01:00,20,V,ugm-3,40,V,ugm-3,5,V,ugm-3 (TEOM FDMS)\n"
            "01-01-2025,24:00,30,V,ugm-3,50,V,ugm-3,No data,,\n")
    df, units = extract.parse_defra_csv(text)
    assert list(df["date"].dt.hour) == [0, 23]                       # hour-ending → beginning
    assert df["no2"].tolist() == [20, 30]                            # NOx not mistaken for NO2
    assert df["pm25"].isna().iloc[1]
    assert "no2" in units
