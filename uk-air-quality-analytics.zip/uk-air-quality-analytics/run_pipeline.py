"""
End-to-end pipeline:

DEFRA UK-AIR → extraction → raw validation → data-quality assessment →
cleaning → feature engineering → analytical datasets → key-findings report

    python run_pipeline.py                 # download + process + report
    python run_pipeline.py --skip-extract  # reprocess data/raw without downloading
    python run_pipeline.py --sites MY1 KC1 MAN3 --years 2024 2025 2026
"""
from __future__ import annotations

import argparse
import logging

import pandas as pd

from src import config as C
from src import extract, report
from src.clean import clean
from src.features import build_daily, build_hourly
from src.quality import assess_quality, validate_raw

log = logging.getLogger("pipeline")


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-extract", action="store_true")
    ap.add_argument("--sites", nargs="*")
    ap.add_argument("--years", nargs="*", type=int)
    ap.add_argument("--refresh", action="store_true", help="re-download every file")
    a = ap.parse_args()

    if not a.skip_extract:
        extract.run(a.sites, a.years, a.refresh)
    raw = pd.read_parquet(C.DATA_RAW / "aurn_hourly_raw.parquet")
    meta = pd.read_csv(C.DATA_RAW / "aurn_metadata.csv")
    log.info("Raw: %s rows, %s sites", f"{len(raw):,}", raw["site_code"].nunique())

    C.DATA_PROCESSED.mkdir(parents=True, exist_ok=True)
    checks = validate_raw(raw, meta)
    checks.to_csv(C.DATA_PROCESSED / "raw_validation.csv", index=False)
    for r in checks.itertuples():
        log.log(logging.INFO if r.passed else logging.WARNING, "[%s] %s %s",
                "PASS" if r.passed else "FAIL", r.check, r.detail)
    critical = {"Required columns present", "At least one target pollutant present", "No null timestamps"}
    if not checks.loc[checks["check"].isin(critical), "passed"].all():
        raise SystemExit("Critical validation failed – see data/processed/raw_validation.csv")

    dq = assess_quality(raw)
    dq.to_csv(C.DATA_PROCESSED / "data_quality.csv", index=False)

    tidy, clog = clean(raw, meta)
    clog.to_csv(C.DATA_PROCESSED / "cleaning_log.csv", index=False)

    hourly = build_hourly(tidy)
    daily = build_daily(hourly)
    hourly.to_parquet(C.DATA_PROCESSED / "hourly_clean.parquet", index=False)
    daily.to_parquet(C.DATA_PROCESSED / "daily_clean.parquet", index=False)
    daily.to_csv(C.DATA_PROCESSED / "daily_clean.csv", index=False)
    log.info("Clean hourly: %s rows | daily: %s rows", f"{len(hourly):,}", f"{len(daily):,}")

    report.write(hourly, daily, dq, report.load_manifest())
    log.info("Report written to reports/key_findings.md")


if __name__ == "__main__":
    main()
