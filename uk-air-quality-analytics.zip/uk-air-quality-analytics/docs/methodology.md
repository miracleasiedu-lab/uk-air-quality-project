# Methodology, Sources and Thresholds

## 1. Data source

| Item | Detail |
|---|---|
| Publisher | Defra and the Devolved Administrations, via UK-AIR (uk-air.defra.gov.uk); files hosted by Ricardo Energy & Environment on Defra's behalf |
| Network | Automatic Urban and Rural Network (AURN): the UK's main automatic air-quality monitoring network |
| Primary service | Hourly site-year files built for the `openair` project: `https://uk-air.defra.gov.uk/openair/R_data/{SITE}_{YEAR}.RData` |
| Metadata | `https://uk-air.defra.gov.uk/openair/R_data/AURN_metadata.RData` (site name, environment type, coordinates) |
| Fallback service | UK-AIR pre-formatted site files, updated daily: `https://uk-air.defra.gov.uk/datastore/data_files/site_data/{SITE}_{YEAR}.csv` |
| Licence | Open Government Licence. Attribution: © Crown copyright Defra via uk-air.defra.gov.uk, licensed under the OGL |
| Study window | Default: the two previous full calendar years plus the current year to date (≥ 24 months of history plus the latest readings). Set in `src/config.py` |

The exact files downloaded, with URL, row count, first/last timestamp and the pollutants found in each, are logged in `data/raw/extraction_manifest.json` on every run.

### Monitoring stations

`src/config.py` lists *candidate* AURN site codes for London and major UK cities. They are not taken on trust. At run time every code is checked against the live DEFRA metadata; codes that are not found, or that have no data for a year, are skipped and recorded in the manifest. Site names, environment types and coordinates in all outputs come from DEFRA metadata. To find codes for other places, run `python -m src.extract --discover "<town>"`.

### Pollutant availability

Not every AURN site measures every pollutant. SO₂ and CO in particular are measured at relatively few urban sites. The pipeline reports exactly which pollutants were found at which sites (`data/processed/data_quality.csv`), and every analysis that needs an absent pollutant is skipped with an explicit "not computed" note rather than filled in.

## 2. Units

As documented for these files by openair/Defra:

| Pollutant | Unit |
|---|---|
| PM2.5, PM10 | µg/m³ (gravimetric or gravimetric-equivalent) |
| NO₂, O₃, SO₂ | µg/m³ (mass units) |
| CO | **mg/m³** |
| Wind speed / direction / temperature | m/s, degrees, °C. These are **modelled** values supplied with the files, not on-site measurements |

When the CSV fallback is used, the unit strings printed in the file are captured in the manifest for checking.

## 3. Timestamps

The RData files use **hour-beginning** GMT timestamps. The UK-AIR CSV files use **hour-ending** stamps (01:00 to 24:00), which the parser shifts back one hour so both sources align. All timestamps are stored in UTC. Calendar features (hour, weekday, month, season) are derived in **Europe/London local time**, because traffic patterns follow the local clock across British Summer Time changes.

## 4. Cleaning rules

1. Exact duplicate rows are dropped. Duplicate site-hours are collapsed, keeping the first non-null value.
2. Negative concentrations are set to missing.
3. Values above physical-plausibility caps are set to missing (µg/m³: PM2.5 1000, PM10 2000, NO₂ 2000, O₃ 1000, SO₂ 3000; CO 100 mg/m³). These are error guards, not health limits.
4. Modelled meteorology outside physical ranges is set to missing.
5. Each site gets a complete hourly grid. Missing hours stay missing. **No imputation** is performed.

Every rule's effect is written to `data/processed/cleaning_log.csv`.

## 5. Averaging and data-capture rules

| Statistic | Rule |
|---|---|
| Daily mean | ≥ 18 valid hours (75 %) |
| 24-hour rolling mean | ≥ 18 valid hours in the window |
| 8-hour rolling mean (O₃) | ≥ 6 valid hours in the window |
| Monthly mean (trend analysis) | ≥ 23 valid daily means |
| Annual-type comparisons | series below 90 % capture are flagged |

## 6. Thresholds

### UK Daily Air Quality Index (DAQI): band lower bounds, µg/m³

| Pollutant | Averaging period | Moderate | High | Very High |
|---|---|---|---|---|
| PM2.5 | 24-hour mean | 36 | 54 | 71 |
| PM10 | 24-hour mean | 51 | 76 | 101 |
| NO₂ | 1-hour mean | 201 | 401 | 601 |
| O₃ | 8-hour running mean | 101 | 161 | 241 |
| SO₂ | 15-minute mean (*applied to hourly means here as an approximation*) | 267 | 533 | 1065 |

Source: Defra / GOV.UK, "Pollutant concentrations for the Daily Air Quality Index (DAQI)".

**High-pollution indicator.** An hour is flagged when any assessable pollutant is in the DAQI *Moderate* band or above on its own averaging period. Daily DAQI bands use the daily mean (PM), the maximum hourly value (NO₂, SO₂) and the maximum 8-hour running mean (O₃).

### WHO 2021 Air Quality Guidelines (µg/m³)

| Pollutant | Annual | 24-hour | 8-hour |
|---|---|---|---|
| PM2.5 | 5 | 15 | – |
| PM10 | 15 | 45 | – |
| NO₂ | 10 | 25 | – |
| O₃ | – | – | 100 (peak season) |

### UK annual-mean limit values (context)

NO₂ 40 µg/m³ · PM10 40 µg/m³ · PM2.5 20 µg/m³.

## 7. Analytical methods

| Method | How it works |
|---|---|
| Correlation | Spearman rank correlation, which is robust to the skewed distributions typical of pollution data |
| Weekday vs weekend | Difference of means, with a Mann–Whitney U test |
| Trend | Theil–Sen median slope of de-seasonalised monthly means (monthly mean minus that site's average for the same calendar month), requiring ≥ 18 valid months. Reported as *indicative* |
| Hotspot score | Mean percentile rank of a site's PM2.5, PM10 and NO₂ means among the selected sites (0–100). The score is relative to the sites chosen. O₃ is excluded because it is a regional secondary pollutant that is usually lower where NO₂ is high |
| Anomalies | Modified z-score of each daily mean against a centred 30-day rolling median and MAD (Iglewicz & Hoaglin); spikes are flagged at z > 3.5. Spikes seen at 3+ sites on the same day are treated as regional episodes |
| PCA | Singular value decomposition of standardised daily means (complete site-days only) |
