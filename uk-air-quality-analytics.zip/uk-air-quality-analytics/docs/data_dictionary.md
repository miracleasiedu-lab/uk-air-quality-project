# Data Dictionary

## Raw layer: `data/raw/`

| File | Contents |
|---|---|
| `aurn_metadata.csv` | DEFRA AURN site metadata, one row per site: `site_code`, `site_name`, `location_type`, `latitude`, `longitude`, `zone`, `agglomeration`, `local_authority`, `start_date`, `end_date` (columns are present when the published file includes them) |
| `aurn_hourly_raw.parquet` | Downloaded hourly data, stacked, with column names normalised and no values changed |
| `extraction_manifest.json` | Per-request provenance: URL, source type, status, rows, first/last timestamp, pollutants found, units seen |
| `cache/` | Original downloaded files |

## Clean hourly dataset: `data/processed/hourly_clean.parquet`

One row per site per hour (complete hourly grid; gaps stay as missing values).

| Column | Type | Description |
|---|---|---|
| `site_code` | str | AURN site code (e.g. MY1) |
| `site_name` | str | DEFRA site name |
| `city` | str | Project grouping label (from `config.CANDIDATE_SITES`) |
| `location_type` | str | DEFRA site environment, e.g. Urban Traffic, Urban Background |
| `latitude`, `longitude` | float | Site coordinates (WGS84) from DEFRA metadata |
| `date` | datetime (UTC) | Start of the measurement hour |
| `datetime_local` | datetime (Europe/London) | `date` in UK local time |
| `date_local` | date | Local calendar date |
| `pm25`, `pm10`, `no2`, `o3`, `so2` | float, µg/m³ | Hourly mean concentration (a column is present only if measured) |
| `co` | float, **mg/m³** | Hourly mean carbon monoxide |
| `ws`, `wd`, `temp` | float | Modelled wind speed (m/s), direction (°), temperature (°C) |
| `year`, `month`, `day`, `hour` | int | Local calendar parts |
| `month_name` | category | January…December |
| `year_month` | str | YYYY-MM |
| `day_of_week` | category | Monday…Sunday |
| `is_weekend` / `day_type` | bool / str | Saturday or Sunday / "Weekday", "Weekend" |
| `season` | category | Meteorological season (Winter = Dec–Feb) |
| `{p}_24h` | float | 24-hour rolling mean (≥ 18 valid hours) |
| `{p}_7d` | float | 7-day rolling mean (≥ 120 valid hours) |
| `o3_8h` | float | 8-hour running mean of ozone (≥ 6 valid hours) |
| `{p}_daqi_band` | category | DAQI band (Low / Moderate / High / Very High) on the pollutant's DAQI averaging period |
| `{p}_high` | float (1/0/NaN) | Pollutant at DAQI Moderate or above |
| `any_daqi_assessed` | bool | At least one DAQI pollutant could be assessed that hour |
| `high_pollution` | float (1/0/NaN) | Any pollutant at DAQI Moderate or above |

## Clean daily dataset: `data/processed/daily_clean.parquet` / `.csv`

| Column | Description |
|---|---|
| `site_code`, `site_name`, `city`, `location_type`, `date_local` | Keys |
| `{p}_mean` | Daily mean; missing if fewer than 18 valid hours |
| `{p}_max` | Daily maximum hourly value (same capture rule) |
| `{p}_n` | Number of valid hours that day |
| `o3_max8h` | Daily maximum 8-hour running mean of ozone |
| `ws_mean`, `temp_mean` | Daily mean modelled wind speed and temperature |
| `year`, `month`, `year_month`, `day_of_week`, `day_type`, `season` | Calendar fields |
| `{p}_daqi_band` | Daily DAQI band (PM: daily mean; NO₂/SO₂: daily max hour; O₃: max 8-hour mean) |
| `{p}_who_exceed` | 1 if the daily mean exceeds the WHO 2021 24-hour guideline (PM2.5, PM10, NO₂) |

## Quality and audit files: `data/processed/`

| File | Description |
|---|---|
| `raw_validation.csv` | Structural checks with pass/fail and detail |
| `data_quality.csv` | Per site × pollutant: expected and valid hours, capture %, negatives, values above the plausibility cap, longest gap, first/last valid hour |
| `cleaning_log.csv` | Each cleaning rule and the number of values it changed |

## Outputs: `reports/`

| File | Description |
|---|---|
| `key_findings.md` | KPIs, insights, recommendations, limitations, conclusion, and provenance, all generated from data |
| `tables/*.csv` | The table behind each KPI and each analysis (U1–U10, B1–B10, M1–M10, TS1, H1, A1, latest readings) |
