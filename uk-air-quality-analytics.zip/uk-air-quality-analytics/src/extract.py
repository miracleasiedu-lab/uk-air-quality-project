"""
Data extraction from DEFRA UK-AIR (AURN network).

Usage
-----
    python -m src.extract                      # default sites and years
    python -m src.extract --years 2024 2025 2026 --sites MY1 KC1 MAN3
    python -m src.extract --discover Manchester  # list real site codes

Outputs (data/raw/)
-------------------
    aurn_metadata.csv          site metadata exactly as published by DEFRA
    aurn_hourly_raw.parquet    every downloaded site-year, stacked, unmodified
                               apart from column-name normalisation
    extraction_manifest.json   one record per request: URL, status, rows,
                               date span, units seen, timestamp
"""
from __future__ import annotations

import argparse
import io
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import requests

from src import config as C

log = logging.getLogger("extract")
CACHE = C.DATA_RAW / "cache"


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
class NotFound(Exception):
    """The requested DEFRA file does not exist (HTTP 404)."""


def _download(url: str, dest: Path, refresh: bool) -> Path:
    if dest.exists() and not refresh:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    last_err: Exception | None = None
    for attempt in range(1, C.HTTP_RETRIES + 1):
        try:
            r = requests.get(url, timeout=C.HTTP_TIMEOUT,
                             headers={"User-Agent": C.USER_AGENT})
            if r.status_code == 404:
                raise NotFound(url)
            r.raise_for_status()
            dest.write_bytes(r.content)
            return dest
        except NotFound:
            raise
        except requests.RequestException as err:
            last_err = err
            log.warning("Attempt %s/%s failed for %s: %s", attempt, C.HTTP_RETRIES, url, err)
            time.sleep(2 * attempt)
    raise ConnectionError(f"Could not download {url}: {last_err}")


def _read_rdata(path: Path) -> pd.DataFrame:
    import pyreadr  # imported here so the rest of the project works without it

    objects = pyreadr.read_r(str(path))
    if not objects:
        raise ValueError(f"No R objects found in {path.name}")
    # Each DEFRA file holds a single data frame; take the first object.
    return next(iter(objects.values()))


# --------------------------------------------------------------------------
# Metadata
# --------------------------------------------------------------------------
def fetch_metadata(refresh: bool = False) -> pd.DataFrame:
    """Download AURN site metadata and return one row per site."""
    path = _download(C.DEFRA_METADATA_URL, CACHE / "AURN_metadata.RData", refresh)
    meta = _read_rdata(path)
    meta.columns = [c.strip().lower() for c in meta.columns]
    if "site_id" not in meta.columns:
        raise ValueError(f"Unexpected metadata layout, columns: {list(meta.columns)}")

    def pick(*names):
        return next((n for n in names if n in meta.columns), None)

    cols = {
        "site_code": "site_id",
        "site_name": pick("site_name", "site"),
        "location_type": pick("location_type", "site_type"),
        "latitude": pick("latitude", "lat"),
        "longitude": pick("longitude", "lon", "long"),
        "zone": pick("zone"),
        "agglomeration": pick("agglomeration"),
        "local_authority": pick("local_authority"),
        "start_date": pick("start_date"),
        "end_date": pick("end_date"),
    }
    out = pd.DataFrame({k: meta[v] if v else pd.NA for k, v in cols.items()})
    out["site_code"] = out["site_code"].astype(str).str.upper().str.strip()
    # The published file is long (one row per site × parameter); collapse it.
    out = out.drop_duplicates("site_code").reset_index(drop=True)
    C.DATA_RAW.mkdir(parents=True, exist_ok=True)
    out.to_csv(C.DATA_RAW / "aurn_metadata.csv", index=False)
    return out


def discover(city: str) -> pd.DataFrame:
    meta = fetch_metadata()
    mask = meta["site_name"].astype(str).str.contains(city, case=False, na=False)
    return meta.loc[mask, ["site_code", "site_name", "location_type",
                           "latitude", "longitude", "end_date"]]


# --------------------------------------------------------------------------
# Site-year data
# --------------------------------------------------------------------------
def _normalise(df: pd.DataFrame) -> pd.DataFrame:
    rename = {}
    for col in df.columns:
        key = str(col).strip().lower()
        if key in C.RAW_COLUMN_MAP:
            rename[col] = C.RAW_COLUMN_MAP[key]
        elif key in ("date", "site", "code"):
            rename[col] = key
    df = df.rename(columns=rename)
    keep = ["date", "site", "code"] + list(C.POLLUTANTS) + list(C.MET_VARIABLES)
    return df[[c for c in keep if c in df.columns]].copy()


def _fetch_rdata(site: str, year: int, refresh: bool) -> pd.DataFrame:
    url = C.DEFRA_RDATA_URL.format(site=site, year=year)
    path = _download(url, CACHE / f"{site}_{year}.RData", refresh)
    df = _normalise(_read_rdata(path))
    df["date"] = pd.to_datetime(df["date"], utc=True)      # hour-beginning, GMT
    df.attrs["url"] = url
    df.attrs["units"] = {}
    return df


_CSV_KEYWORDS = [  # order matters: check NOx before NO2
    ("nitrogen oxides", None), ("nitric oxide", None),
    ("pm2.5", "pm25"), ("pm10", "pm10"),
    ("nitrogen dioxide", "no2"), ("ozone", "o3"),
    ("sulphur dioxide", "so2"), ("sulfur dioxide", "so2"),
    ("carbon monoxide", "co"),
    ("wind speed", "ws"), ("wind direction", "wd"), ("temperature", "temp"),
]


def parse_defra_csv(text: str) -> tuple[pd.DataFrame, dict]:
    """Parse a UK-AIR pre-formatted site CSV (Date, time, then
    value/status/unit triplets). The header row is located rather than
    assumed, and the layout is validated; any mismatch raises an error."""
    lines = text.splitlines()
    header_idx = next((i for i, ln in enumerate(lines)
                       if ln.split(",")[0].strip().strip('"').lower() == "date"), None)
    if header_idx is None:
        raise ValueError("No 'Date' header row found in DEFRA CSV")
    raw = pd.read_csv(io.StringIO("\n".join(lines[header_idx:])), dtype=str)
    cols = list(raw.columns)
    if len(cols) < 3 or cols[1].strip().lower() != "time":
        raise ValueError(f"Unexpected DEFRA CSV header: {cols[:5]}")

    out, units = {}, {}
    for i, col in enumerate(cols[2:], start=2):
        name = col.strip().lower()
        if name.startswith(("status", "unit")):
            continue
        code = next((c for kw, c in _CSV_KEYWORDS if kw in name), None)
        if code is None or code in out:
            continue
        out[code] = pd.to_numeric(raw[col], errors="coerce")
        if i + 2 < len(cols) and cols[i + 2].lower().startswith("unit"):
            seen = raw[cols[i + 2]].dropna().unique()
            units[code] = [str(u) for u in seen[:3]]
    if not out:
        raise ValueError("No recognised pollutant columns in DEFRA CSV")

    # Files use hour-ENDING stamps 01:00 … 24:00; convert to hour-beginning.
    day = pd.to_datetime(raw[cols[0]], dayfirst=True, errors="coerce")
    hour = raw[cols[1]].str.extract(r"(\d{1,2})")[0].astype(float)
    date = (day + pd.to_timedelta(hour - 1, unit="h")).dt.tz_localize("UTC")
    df = pd.DataFrame({"date": date, **out}).dropna(subset=["date"])
    return df, units


def _fetch_csv(site: str, year: int, refresh: bool) -> pd.DataFrame:
    url = C.DEFRA_CSV_URL.format(site=site, year=year)
    path = _download(url, CACHE / f"{site}_{year}.csv", refresh)
    df, units = parse_defra_csv(path.read_text(encoding="utf-8", errors="replace"))
    df.attrs["url"] = url
    df.attrs["units"] = units
    return df


def fetch_site_year(site: str, year: int, refresh: bool) -> tuple[pd.DataFrame | None, dict]:
    record = {"site": site, "year": year, "requested_at": datetime.now(timezone.utc).isoformat()}
    for source, fn in (("rdata", _fetch_rdata), ("csv", _fetch_csv)):
        try:
            df = fn(site, year, refresh)
            pols = [p for p in C.POLLUTANTS if p in df.columns and df[p].notna().any()]
            record.update(source=source, url=df.attrs["url"], status="ok", rows=len(df),
                          first=str(df["date"].min()), last=str(df["date"].max()),
                          pollutants_with_data=pols, units_reported_in_file=df.attrs["units"])
            df["site_code"] = site
            df["source_file"] = source
            keep = ["date", "site_code", "source_file"] + [
                c for c in list(C.POLLUTANTS) + list(C.MET_VARIABLES) if c in df.columns]
            return df[keep], record
        except NotFound:
            record.setdefault("not_found", []).append(source)
        except Exception as err:  # noqa: BLE001 – log every failure in the manifest
            record.setdefault("errors", []).append(f"{source}: {err}")
    record["status"] = "missing"
    return None, record


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------
def run(sites: list[str] | None = None, years: list[int] | None = None,
        refresh: bool = False) -> pd.DataFrame:
    sites = [s.upper() for s in (sites or C.CANDIDATE_SITES)]
    years = years or C.YEARS
    meta = fetch_metadata(refresh=refresh)
    known = set(meta["site_code"])
    manifest = {"source": "DEFRA UK-AIR, Automatic Urban and Rural Network (AURN)",
                "metadata_url": C.DEFRA_METADATA_URL, "attribution": C.ATTRIBUTION,
                "run_at": datetime.now(timezone.utc).isoformat(),
                "sites_requested": sites, "years_requested": years,
                "sites_not_in_metadata": sorted(set(sites) - known), "files": []}
    for s in manifest["sites_not_in_metadata"]:
        log.warning("Site %s not found in DEFRA metadata – skipped", s)

    frames = []
    for site in [s for s in sites if s in known]:
        for year in years:
            # The current year is always re-downloaded to get the latest readings.
            df, rec = fetch_site_year(site, year, refresh or year == C.CURRENT_YEAR)
            manifest["files"].append(rec)
            log.info("%s %s → %s", site, year, rec.get("status"))
            if df is not None and len(df):
                frames.append(df)

    if not frames:
        raise RuntimeError("No data downloaded – see data/raw/extraction_manifest.json")
    raw = pd.concat(frames, ignore_index=True)
    raw.to_parquet(C.DATA_RAW / "aurn_hourly_raw.parquet", index=False)
    (C.DATA_RAW / "extraction_manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    return raw


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sites", nargs="*", help="AURN site codes (default: config.CANDIDATE_SITES)")
    ap.add_argument("--years", nargs="*", type=int, help="Years (default: config.YEARS)")
    ap.add_argument("--refresh", action="store_true", help="Ignore the download cache")
    ap.add_argument("--discover", metavar="TEXT", help="List AURN sites whose name contains TEXT")
    a = ap.parse_args()
    if a.discover:
        print(discover(a.discover).to_string(index=False))
        return
    raw = run(a.sites, a.years, a.refresh)
    print(f"Downloaded {len(raw):,} hourly rows for {raw['site_code'].nunique()} sites.")


if __name__ == "__main__":
    main()
