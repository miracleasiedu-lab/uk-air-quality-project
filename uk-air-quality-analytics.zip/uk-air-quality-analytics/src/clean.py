"""
Cleaning pipeline: raw DEFRA hourly data → clean hourly panel.

Every rule is logged with the number of values it affected, and the log is
saved to data/processed/cleaning_log.csv so the cleaning is auditable.
"""
from __future__ import annotations

import pandas as pd

from src import config as C


def clean(raw: pd.DataFrame, meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    log = []

    def note(step, affected, detail=""):
        log.append({"step": step, "values_affected": int(affected), "detail": detail})

    df = raw.copy()
    pols = [p for p in C.POLLUTANTS if p in df.columns]
    met = [m for m in C.MET_VARIABLES if m in df.columns]
    note("Rows received", len(df))

    # 1. Exact duplicate rows
    before = len(df)
    df = df.drop_duplicates()
    note("Drop exact duplicate rows", before - len(df))

    # 2. Duplicate site-hours (e.g. a site-year downloaded from both sources):
    #    keep the first non-null value of each column.
    before = len(df)
    df = (df.sort_values(["site_code", "date", "source_file"])
            .groupby(["site_code", "date"], as_index=False).first())
    note("Collapse duplicate site-hour records", before - len(df))

    # 3. Negative concentrations are physically impossible → missing.
    for p in pols:
        bad = df[p] < 0
        note(f"Negative {p} set to missing", bad.sum())
        df.loc[bad, p] = pd.NA

    # 4. Values above physical-plausibility caps → missing.
    for p in pols:
        bad = df[p] > C.PLAUSIBILITY_MAX[p]
        note(f"{p} > {C.PLAUSIBILITY_MAX[p]} set to missing", bad.sum(), "plausibility cap")
        df.loc[bad, p] = pd.NA

    # 5. Implausible modelled meteorology.
    if "ws" in df:
        bad = (df["ws"] < 0) | (df["ws"] > 75)
        note("Wind speed outside 0–75 m/s set to missing", bad.sum())
        df.loc[bad, "ws"] = pd.NA
    if "wd" in df:
        bad = (df["wd"] < 0) | (df["wd"] > 360)
        note("Wind direction outside 0–360° set to missing", bad.sum())
        df.loc[bad, "wd"] = pd.NA
    if "temp" in df:
        bad = (df["temp"] < -40) | (df["temp"] > 50)
        note("Temperature outside −40–50 °C set to missing", bad.sum())
        df.loc[bad, "temp"] = pd.NA

    # 6. Complete hourly grid per site (needed for correct rolling windows).
    #    Missing hours stay missing; nothing is imputed.
    parts = []
    for site, g in df.groupby("site_code"):
        full = pd.date_range(g["date"].min(), g["date"].max(), freq="h", name="date")
        g = g.set_index("date").reindex(full)
        g["site_code"] = site
        parts.append(g.reset_index())
    added = sum(len(p) for p in parts) - len(df)
    df = pd.concat(parts, ignore_index=True)
    note("Insert missing hours as explicit gaps (no imputation)", added)

    # 7. Drop pollutant columns with no valid values at all.
    empty = [p for p in pols if df[p].isna().all()]
    df = df.drop(columns=empty)
    note("Drop pollutants with no data", len(empty), ", ".join(empty))

    # 8. Attach DEFRA site metadata. City is the project's grouping label.
    m = meta[["site_code", "site_name", "location_type", "latitude", "longitude"]]
    df = df.merge(m, on="site_code", how="left")
    df["city"] = df["site_code"].map(C.CANDIDATE_SITES).fillna(df["site_name"])

    for p in [p for p in pols if p in df] + met:
        df[p] = pd.to_numeric(df[p], errors="coerce").astype("float64")
    df = df.drop(columns=["source_file"], errors="ignore")
    note("Rows in clean hourly panel", len(df))
    return df.sort_values(["site_code", "date"]).reset_index(drop=True), pd.DataFrame(log)
