"""
Builds reports/key_findings.md from the processed data.

All numbers and the selection of recommendations come from computed results.
Recommendations are rule-based: each rule fires only when the data support it,
and the evidence that triggered it is quoted next to it.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone

import pandas as pd

from src import analysis as A
from src import config as C
from src.features import to_long


def run_all(hourly: pd.DataFrame, daily: pd.DataFrame, dq: pd.DataFrame) -> dict:
    long = to_long(hourly)
    return {
        "kpis": A.kpis(hourly),
        "univariate": A.univariate(long, hourly, daily, dq),
        "bivariate": A.bivariate(hourly, daily),
        "multivariate": A.multivariate(hourly, daily),
        "trend": A.trends(daily),
        "hotspots": A.hotspots(hourly, daily),
        "anomalies": A.anomalies(daily),
        "latest": A.latest_readings(hourly),
    }


def _by_id(res: dict) -> dict:
    out = {}
    for k in ("univariate", "bivariate", "multivariate"):
        out.update({r.id: r for r in res[k]})
    for k in ("trend", "hotspots", "anomalies"):
        out[res[k].id] = res[k]
    return out


def recommendations(hourly, daily, dq, res) -> list[str]:
    r, R = [], _by_id(res)
    hs = res["hotspots"].table
    if len(hs):
        top = hs.head(3)
        traffic = top["location_type"].astype(str).str.contains("Traffic", case=False).sum()
        if traffic >= 2:
            r.append(f"**Prioritise roadside interventions.** {traffic} of the top-3 hotspot sites are traffic sites "
                     f"({', '.join(top.site_name)}). Traffic-management, low-emission-zone and bus-fleet measures "
                     "should be evaluated at these corridors first.")
        r.append(f"**Focus monitoring and response on {top.iloc[0].site_name}.** It has the highest composite hotspot "
                 f"score ({top.iloc[0].hotspot_score:.0f}/100) among the sites analysed.")
    b3 = R.get("B3")
    if b3 is not None and len(b3.table):
        pk = int(b3.table.loc[b3.table["no2"].idxmax(), "hour"])
        ratio = b3.table["no2"].max() / b3.table["no2"].min()
        if pk in (6, 7, 8, 9, 16, 17, 18, 19) and ratio >= 1.2:
            r.append(f"**Time-target NO₂ messaging.** Mean NO₂ peaks at {pk:02d}:00, which coincides with commuting "
                     "hours; exposure advice for walkers and cyclists can be timed accordingly.")
    if "pm25_mean" in daily:
        s = daily.groupby("season", observed=True)["pm25_mean"].mean()
        if len(s) and s.idxmax() in ("Winter", "Autumn") and s.max() >= 1.15 * s.min():
            r.append(f"**Prepare for heating-season PM2.5.** Mean PM2.5 is highest in {s.idxmax()} "
                     f"({s.max():.1f} µg/m³ vs {s.min():.1f} in {s.idxmin()}). Seasonal public-health messaging "
                     "and investigation of heating-related sources are warranted.")
    b8 = R.get("B8")
    if b8 is not None and len(b8.table) and b8.table["value"].iloc[-1] > 0.3:
        r.append("**Use temperature forecasts for ozone alerts.** Daily max 8-hour ozone rises with temperature "
                 f"(ρ = {b8.table['value'].iloc[-1]:.2f}); warm-spell forecasts are a practical early-warning trigger.")
    u9 = R.get("U9")
    if u9 is not None and len(u9.table) and u9.table["value"].iloc[-1] > 10:
        r.append(f"**Benchmark against WHO guidelines, not only legal limits.** {u9.table['value'].iloc[-1]:.0f} % of "
                 "site-days exceed the WHO 24-hour PM2.5 guideline even where DAQI bands are mostly 'Low'.")
    an = res["anomalies"].table
    if len(an):
        shared = an.groupby(["date", "pollutant"])["site_name"].nunique()
        if (shared >= 3).any():
            r.append(f"**Distinguish regional episodes from local incidents.** {int((shared >= 3).sum())} spike days "
                     "affected 3+ sites at once; these call for regional alerts rather than local enforcement.")
    if len(dq):
        low = dq[dq["capture_pct"] < 100 * C.ANNUAL_MIN_CAPTURE]
        if len(low):
            r.append(f"**Improve data capture.** {len(low)} site-pollutant series are below "
                     f"{100 * C.ANNUAL_MIN_CAPTURE:.0f} % capture (lowest: {low.nsmallest(1, 'capture_pct').iloc[0].site_code} "
                     f"{low.nsmallest(1, 'capture_pct').iloc[0].pollutant}, {low['capture_pct'].min():.1f} %).")
    r.append("**Re-run on ratified data.** Repeat the analysis once DEFRA ratifies the current year, and extend "
             "the window to 5+ years before drawing firm trend conclusions.")
    return r


def limitations(hourly, dq, res) -> list[str]:
    lim = [
        "Recent data (typically the current year and part of the previous one) are provisional and may change on ratification.",
        "AURN sites are point measurements; a site describes its immediate environment, not a whole city.",
        "Site selection is purposive (London plus major cities) and not representative of the UK as a whole.",
        "Wind speed, direction and temperature in these files are modelled values, not on-site measurements.",
        "DAQI SO₂ bands are defined on 15-minute means; this project applies them to hourly means as an approximation.",
        "A few years of data cannot separate long-term trends from year-to-year weather variability; trend slopes are indicative.",
        "Correlations describe co-variation only and do not establish causes.",
        "Missing hours were left as gaps (no imputation); means use available hours with documented capture rules.",
    ]
    absent = [C.POLLUTANTS[p][0] for p in C.POLLUTANTS if p not in hourly]
    if absent:
        lim.append(f"Not measured at any selected site in this window: {', '.join(absent)}.")
    if len(dq):
        sparse = dq.groupby("pollutant")["site_code"].nunique()
        total = dq["site_code"].nunique()
        few = [f"{C.POLLUTANTS[p][0]} ({n} of {total} sites)" for p, n in sparse.items() if n < 0.5 * total]
        if few:
            lim.append("Pollutants measured at only a few of the selected sites (comparisons are limited): " + ", ".join(few) + ".")
    return lim


def write(hourly: pd.DataFrame, daily: pd.DataFrame, dq: pd.DataFrame, manifest: dict | None = None) -> str:
    res = run_all(hourly, daily, dq)
    tables = C.REPORTS / "tables"
    tables.mkdir(parents=True, exist_ok=True)
    res["kpis"].to_csv(tables / "kpis.csv", index=False)
    res["latest"].to_csv(tables / "latest_readings.csv", index=False)
    for r in _by_id(res).values():
        if len(r.table):
            slug = re.sub(r"[^A-Za-z0-9]+", "_", r.title.replace("₂", "2").replace("₃", "3")).strip("_").lower()
            r.table.to_csv(tables / f"{r.id}_{slug}.csv", index=False)

    start = hourly["datetime_local"].min()
    end = hourly.dropna(subset=A.pollutants_in(hourly), how="all")["datetime_local"].max()
    L = [
        "# Key Findings – UK Air Quality Monitoring",
        "",
        f"_Generated {datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC from DEFRA UK-AIR (AURN) data "
        f"covering {start:%d %b %Y} to {end:%d %b %Y %H:%M} (UK time). {C.ATTRIBUTION}_",
        "",
        f"Sites analysed: {hourly['site_code'].nunique()} — " + ", ".join(sorted(hourly['site_name'].dropna().unique())) + ".",
        "",
        "## KPIs", "",
        res["kpis"].to_markdown(index=False), "",
        "## Insights", "",
    ]
    for section in ("univariate", "bivariate", "multivariate"):
        L += [f"### {section.title()} analysis", ""]
        L += [f"- **{r.id} {r.title}** — {r.finding}" for r in res[section]]
        L.append("")
    L += ["### Time series, hotspots and anomalies", ""]
    L += [f"- **{res[k].id} {res[k].title}** — {res[k].finding}" for k in ("trend", "hotspots", "anomalies")]
    L += ["", "## Recommendations", ""]
    L += [f"{i}. {t}" for i, t in enumerate(recommendations(hourly, daily, dq, res), 1)]
    L += ["", "## Limitations", ""]
    L += [f"- {t}" for t in limitations(hourly, dq, res)]
    L += ["", "## Conclusion", "", conclusion(hourly, daily, res), ""]
    if manifest:
        ok = [f for f in manifest.get("files", []) if f.get("status") == "ok"]
        L += ["## Data provenance", "",
              f"{len(ok)} site-year files downloaded on {manifest.get('run_at', '')[:10]}; "
              f"sites not found in DEFRA metadata: {manifest.get('sites_not_in_metadata') or 'none'}. "
              "Full list in `data/raw/extraction_manifest.json`.", ""]
    text = "\n".join(L)
    (C.REPORTS / "key_findings.md").write_text(text, encoding="utf-8")
    return text


def conclusion(hourly, daily, res) -> str:
    """Assemble the conclusion only from statements the data support."""
    R, parts = _by_id(res), []
    n = hourly["site_code"].nunique()
    hs = res["hotspots"].table
    if len(hs):
        parts.append(f"Across {n} AURN monitoring sites, the strongest pollution hotspots are "
                     f"{', '.join(hs.head(2).site_name)}.")
    b3 = R.get("B3")
    if b3 is not None and len(b3.table):
        t = b3.table
        ratio = t["no2"].max() / t["no2"].min()
        if ratio >= 1.2:
            parts.append(f"NO₂ follows a pronounced daily cycle (peak {int(t.loc[t.no2.idxmax(), 'hour']):02d}:00, "
                         f"{ratio:.1f}× the daily minimum).")
    if "pm25_mean" in daily:
        s = daily.groupby("season", observed=True)["pm25_mean"].mean().dropna()
        if len(s) > 1 and s.max() >= 1.15 * s.min():
            parts.append(f"PM2.5 is seasonal, highest in {s.idxmax()} and lowest in {s.idxmin()}.")
    an = res["anomalies"].table
    if len(an):
        multi = (an.groupby(["date", "pollutant"])["site_name"].nunique() >= 3).sum()
        if multi:
            parts.append(f"{multi} spike days affected three or more sites at once, pointing to regional episodes.")
    tr = res["trend"].table
    if len(tr):
        parts.append(f"{(tr['slope_per_year'] < 0).mean() * 100:.0f} % of site-pollutant series trend downward, "
                     "but the window is too short for firm conclusions.")
    parts.append("Every statement here is generated from the retrieved DEFRA data and updates when the pipeline is re-run.")
    return " ".join(parts)


def load_manifest() -> dict | None:
    p = C.DATA_RAW / "extraction_manifest.json"
    return json.loads(p.read_text()) if p.exists() else None
