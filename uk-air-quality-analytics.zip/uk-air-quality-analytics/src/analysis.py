"""
Analysis layer shared by the notebook, the report generator and the dashboard.

Every function computes its output from the data passed in. The `finding`
text of each Result is generated from the computed table, so no number in
any narrative is typed by hand.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from src import config as C
from src.features import DAY_ORDER, MONTH_ORDER, SEASON_ORDER, pollutants_in

TEMPLATE = "plotly_white"
SAMPLE_MAX = 20_000  # scatter points drawn (statistics always use all data)


@dataclass
class Result:
    id: str
    title: str
    question: str
    table: pd.DataFrame = field(default_factory=pd.DataFrame)
    fig: go.Figure | None = None
    finding: str = ""


def name(p: str) -> str:
    return C.POLLUTANTS[p][0] if p in C.POLLUTANTS else p


def unit(p: str) -> str:
    return C.POLLUTANTS[p][1] if p in C.POLLUTANTS else ""


def _missing(rid, title, question, what) -> Result:
    return Result(rid, title, question, finding=f"Not computed: {what} not present in the retrieved data.")


def _fmt(x, nd=1):
    return "n/a" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:,.{nd}f}"


# ==========================================================================
# KPIs
# ==========================================================================
def kpis(hourly: pd.DataFrame, site_pollutant: str = "no2", month_pollutant: str = "pm25") -> pd.DataFrame:
    rows = []

    def add(n, label, value, detail=""):
        rows.append({"kpi": n, "name": label, "value": value, "detail": detail})

    for i, p in enumerate(["pm25", "pm10", "no2", "o3"], start=1):
        v = hourly[p].mean() if p in hourly else np.nan
        add(i, f"Average {name(p)}", _fmt(v) + f" {unit(p)}" if p in hourly else "n/a",
            f"mean of {int(hourly[p].notna().sum()):,} valid hourly values" if p in hourly else "pollutant not retrieved")

    for i, p in ((5, "pm25"), (6, "no2")):
        if p in hourly and hourly[p].notna().any():
            r = hourly.loc[hourly[p].idxmax()]
            add(i, f"Maximum hourly {name(p)}", f"{r[p]:,.1f} {unit(p)}",
                f"{r['site_name']} at {r['datetime_local']:%Y-%m-%d %H:%M} (UK time)")
        else:
            add(i, f"Maximum hourly {name(p)}", "n/a", "pollutant not retrieved")

    pols = pollutants_in(hourly)
    active = hourly.loc[hourly[pols].notna().any(axis=1), "site_code"].nunique()
    add(7, "Monitoring stations analysed", f"{active}", "sites with ≥ 1 valid pollutant reading")

    if "high_pollution" in hourly:
        assessed = hourly["high_pollution"].notna()
        n_high = int((hourly.loc[assessed, "high_pollution"] == 1).sum())
        pct = 100 * n_high / max(int(assessed.sum()), 1)
        add(8, "High-pollution site-hours", f"{n_high:,} ({pct:.2f} %)",
            "DAQI Moderate or above for any of PM2.5 (24-h mean), PM10 (24-h mean), "
            "NO₂ (hourly), O₃ (8-h mean), SO₂ (hourly)")

    p = site_pollutant
    if p in hourly:
        s = hourly.groupby("site_name")[p].agg(["mean", "count"]).dropna()
        top = s["mean"].idxmax()
        add(9, f"Highest-average location ({name(p)})", top,
            f"{s.loc[top, 'mean']:.1f} {unit(p)} over {int(s.loc[top, 'count']):,} hours")

    p = month_pollutant
    if p in hourly:
        m = hourly.groupby("year_month")[p].mean().dropna()
        add(10, f"Highest-average month ({name(p)})", m.idxmax(),
            f"{m.max():.1f} {unit(p)} (all selected sites)")
    return pd.DataFrame(rows)


# ==========================================================================
# Univariate (10)
# ==========================================================================
def _distribution(long: pd.DataFrame, p: str, rid: str) -> Result:
    title = f"Distribution of hourly {name(p)}"
    q = f"What does a typical hour of {name(p)} look like, and how heavy is the upper tail?"
    s = long.loc[long["pollutant"] == p, "value"]
    if s.empty:
        return _missing(rid, title, q, name(p))
    t = pd.DataFrame({"statistic": ["count", "mean", "median", "std", "p95", "p99", "max", "skewness"],
                      "value": [len(s), s.mean(), s.median(), s.std(), s.quantile(.95),
                                s.quantile(.99), s.max(), s.skew()]})
    clip = s.quantile(.995)
    fig = px.histogram(s[s <= clip], nbins=80, template=TEMPLATE,
                       labels={"value": f"{name(p)} ({unit(p)})"}, title=title + " (≤ 99.5th pct shown)")
    fig.update_layout(showlegend=False, yaxis_title="hours")
    f = (f"Median {s.median():.1f} {unit(p)}, mean {s.mean():.1f}; 95th percentile "
         f"{s.quantile(.95):.1f}. Skewness {s.skew():.2f} "
         f"({'right-skewed: episodic peaks well above typical levels' if s.skew() > 1 else 'moderately symmetric'}).")
    return Result(rid, title, q, t, fig, f)


def univariate(long: pd.DataFrame, hourly: pd.DataFrame, daily: pd.DataFrame, dq: pd.DataFrame) -> list[Result]:
    out = [_distribution(long, p, f"U{i}") for i, p in enumerate(C.POLLUTANT_ORDER, start=1)]

    # U7 – daily DAQI band frequencies
    q = "How often does each pollutant reach each DAQI band on a daily basis?"
    cols = [c for c in daily if c.endswith("_daqi_band")]
    if cols:
        t = pd.concat([daily[c].value_counts().rename(name(c.replace("_daqi_band", "")))
                       for c in cols], axis=1).reindex(C.DAQI_BANDS).fillna(0).astype(int)
        t.index.name = "band"
        tl = t.reset_index().melt(id_vars="band", var_name="pollutant", value_name="site_days")
        fig = px.bar(tl, x="pollutant", y="site_days", color="band", template=TEMPLATE,
                     title="Daily DAQI band frequency (site-days)", barmode="stack",
                     color_discrete_sequence=["#5aa469", "#f2c14e", "#e4572e", "#7b2d26"])
        nonlow = (t.drop("Low").sum() / t.sum() * 100).sort_values(ascending=False)
        f = "Share of assessed site-days above 'Low': " + "; ".join(f"{k} {v:.1f} %" for k, v in nonlow.items()) + "."
        out.append(Result("U7", "DAQI band frequency", q, t.reset_index(), fig, f))
    else:
        out.append(_missing("U7", "DAQI band frequency", q, "DAQI pollutants"))

    # U8 – data capture
    q = "How complete is the record for each site and pollutant?"
    if len(dq):
        t = dq[["site_code", "pollutant", "capture_pct", "longest_gap_hours"]].sort_values("capture_pct")
        fig = px.bar(t, x="capture_pct", y="site_code", color="pollutant", barmode="group",
                     orientation="h", template=TEMPLATE, title="Data capture by site and pollutant (%)",
                     height=max(400, 22 * t["site_code"].nunique() * 2))
        fig.add_vline(x=100 * C.ANNUAL_MIN_CAPTURE, line_dash="dash")
        low = (dq["capture_pct"] < 100 * C.ANNUAL_MIN_CAPTURE).sum()
        f = (f"Median capture {dq['capture_pct'].median():.1f} %. {low} of {len(dq)} site-pollutant "
             f"series fall below the {100 * C.ANNUAL_MIN_CAPTURE:.0f} % benchmark.")
        out.append(Result("U8", "Data capture", q, t, fig, f))

    # U9 – daily PM2.5 vs WHO 24h guideline
    q = "On what share of days does daily-mean PM2.5 exceed the WHO 24-hour guideline?"
    if "pm25_mean" in daily:
        s = daily["pm25_mean"].dropna()
        lim = C.WHO_2021["pm25"]["24h"]
        pct = 100 * (s > lim).mean()
        t = pd.DataFrame({"metric": ["valid site-days", f"days > {lim} µg/m³", "% of days"],
                          "value": [len(s), int((s > lim).sum()), round(pct, 1)]})
        fig = px.histogram(s, nbins=60, template=TEMPLATE, title="Daily-mean PM2.5 (site-days)",
                           labels={"value": "PM2.5 daily mean (µg/m³)"})
        fig.add_vline(x=lim, line_dash="dash", annotation_text="WHO 24-h guideline")
        fig.update_layout(showlegend=False)
        out.append(Result("U9", "Daily PM2.5 against WHO guideline", q, t, fig,
                          f"{pct:.1f} % of valid site-days exceed the WHO 2021 24-hour PM2.5 guideline ({lim} µg/m³)."))
    else:
        out.append(_missing("U9", "Daily PM2.5 against WHO guideline", q, "PM2.5"))

    # U10 – daily maximum NO2
    q = "How high do daily NO₂ peaks get?"
    if "no2_max" in daily:
        s = daily["no2_max"].dropna()
        t = s.describe(percentiles=[.5, .9, .99]).rename("daily max NO₂").reset_index()
        fig = px.box(daily.dropna(subset=["no2_max"]), x="no2_max", template=TEMPLATE,
                     title="Daily maximum hourly NO₂ (site-days)", labels={"no2_max": "µg/m³"})
        f = (f"Median daily peak {s.median():.1f} µg/m³; 99th percentile {s.quantile(.99):.1f}. "
             f"{int((s >= C.DAQI['no2']['moderate']).sum())} site-days reached the DAQI Moderate NO₂ band.")
        out.append(Result("U10", "Daily NO₂ peaks", q, t, fig, f))
    else:
        out.append(_missing("U10", "Daily NO₂ peaks", q, "NO₂"))
    return out


# ==========================================================================
# Bivariate (10)
# ==========================================================================
def _scatter_pair(hourly, a, b, rid, title, q, extra=""):
    if a not in hourly or b not in hourly:
        return _missing(rid, title, q, f"{name(a)} and {name(b)}")
    d = hourly[[a, b, "location_type"]].dropna()
    if len(d) < 30:
        return _missing(rid, title, q, "enough co-located hours")
    pear, spear = d[a].corr(d[b]), d[a].corr(d[b], method="spearman")
    t = pd.DataFrame({"metric": ["co-located hours", "Pearson r", "Spearman ρ"],
                      "value": [len(d), round(pear, 3), round(spear, 3)]})
    fig = px.scatter(d.sample(min(len(d), SAMPLE_MAX), random_state=0), x=a, y=b, color="location_type",
                     opacity=.35, template=TEMPLATE, title=title,
                     labels={a: f"{name(a)} ({unit(a)})", b: f"{name(b)} ({unit(b)})"})
    f = f"Spearman ρ = {spear:.2f} (Pearson r = {pear:.2f}) across {len(d):,} co-located hours. {extra}"
    return Result(rid, title, q, t, fig, f.strip()), d


def bivariate(hourly: pd.DataFrame, daily: pd.DataFrame) -> list[Result]:
    out = []

    # B1 – PM2.5 vs PM10
    r = _scatter_pair(hourly, "pm25", "pm10", "B1", "PM2.5 vs PM10",
                      "How closely do fine and coarse particles move together?")
    if isinstance(r, tuple):
        res, d = r
        d = d[d["pm10"] > 0]
        ratio = (d["pm25"] / d["pm10"]).clip(upper=1.5).median()
        res.finding += f" Median PM2.5/PM10 ratio {ratio:.2f}."
        res.table.loc[len(res.table)] = ["median PM2.5/PM10 ratio", round(ratio, 3)]
        r = res
    out.append(r)

    # B2 – NO2 vs O3
    r = _scatter_pair(hourly, "no2", "o3", "B2", "NO₂ vs O₃",
                      "Do NO₂ and ozone move in opposite directions (NO titration)?")
    out.append(r[0] if isinstance(r, tuple) else r)

    # B3 – NO2 by hour
    q = "How does NO₂ change through the day?"
    if "no2" in hourly:
        t = hourly.groupby("hour")["no2"].mean().reset_index()
        fig = px.line(t, x="hour", y="no2", markers=True, template=TEMPLATE,
                      title="Mean NO₂ by hour of day (UK local time)", labels={"no2": "µg/m³"})
        hi, lo = t.loc[t["no2"].idxmax()], t.loc[t["no2"].idxmin()]
        f = (f"Peak at {int(hi.hour):02d}:00 ({hi.no2:.1f} µg/m³), minimum at {int(lo.hour):02d}:00 "
             f"({lo.no2:.1f}); peak is {hi.no2 / lo.no2:.1f}× the minimum.")
        out.append(Result("B3", "NO₂ by hour of day", q, t, fig, f))
    else:
        out.append(_missing("B3", "NO₂ by hour of day", q, "NO₂"))

    # B4 – PM2.5 by month
    q = "Which calendar months have the highest PM2.5?"
    if "pm25" in hourly:
        t = hourly.groupby("month_name", observed=True)["pm25"].mean().reindex(MONTH_ORDER).dropna().reset_index()
        fig = px.bar(t, x="month_name", y="pm25", template=TEMPLATE, title="Mean PM2.5 by calendar month",
                     labels={"pm25": "µg/m³", "month_name": ""})
        f = (f"Highest in {t.loc[t.pm25.idxmax(), 'month_name']} ({t.pm25.max():.1f} µg/m³), lowest in "
             f"{t.loc[t.pm25.idxmin(), 'month_name']} ({t.pm25.min():.1f}).")
        out.append(Result("B4", "PM2.5 by month", q, t, fig, f))
    else:
        out.append(_missing("B4", "PM2.5 by month", q, "PM2.5"))

    # B5 – weekday vs weekend
    q = "Are weekday pollution levels different from weekends?"
    pols = pollutants_in(hourly)
    if pols:
        t = hourly.groupby("day_type")[pols].mean().T
        t["weekend_vs_weekday_pct"] = 100 * (t["Weekend"] / t["Weekday"] - 1)
        t.index = [name(p) for p in t.index]
        tests = {}
        try:
            from scipy.stats import mannwhitneyu
            for p in pols:
                a = hourly.loc[hourly.day_type == "Weekday", p].dropna()
                b = hourly.loc[hourly.day_type == "Weekend", p].dropna()
                if len(a) > 30 and len(b) > 30:
                    tests[name(p)] = mannwhitneyu(a, b).pvalue
        except ImportError:
            pass
        t["mann_whitney_p"] = pd.Series(tests)
        tl = t[["Weekday", "Weekend"]].reset_index(names="pollutant").melt(id_vars="pollutant", var_name="day_type")
        fig = px.bar(tl, x="pollutant", y="value", color="day_type", barmode="group",
                     template=TEMPLATE, title="Weekday vs weekend means", labels={"value": "concentration"})
        f = "Weekend vs weekday: " + "; ".join(
            f"{k} {v:+.1f} %" for k, v in t["weekend_vs_weekday_pct"].items()) + "."
        out.append(Result("B5", "Weekday vs weekend", q, t.round(4).reset_index(names="pollutant"), fig, f))

    # B6 – by location type
    q = "How do concentrations differ between site environments (e.g. traffic vs background)?"
    if pols and hourly["location_type"].notna().any():
        t = hourly.groupby("location_type")[pols].mean().round(2)
        t.columns = [name(c) for c in t.columns]
        tl = t.reset_index().melt(id_vars="location_type", var_name="pollutant")
        fig = px.bar(tl, x="pollutant", y="value", color="location_type", barmode="group",
                     template=TEMPLATE, title="Mean concentration by site environment")
        f = "Highest-mean environment per pollutant: " + "; ".join(
            f"{c}: {t[c].idxmax()}" for c in t.columns) + "."
        out.append(Result("B6", "Concentration by site environment", q, t.reset_index(), fig, f))

    # B7 – NO2 vs wind speed
    q = "Does NO₂ fall as (modelled) wind speed rises?"
    if {"no2", "ws"} <= set(hourly.columns) and hourly["ws"].notna().sum() > 100:
        d = hourly[["no2", "ws"]].dropna()
        d["ws_bin"] = pd.cut(d["ws"], [0, 2, 4, 6, 8, 10, 15, 75], include_lowest=True).astype(str)
        t = d.groupby("ws_bin", sort=False)["no2"].agg(["mean", "count"]).reset_index()
        t = t.sort_values("ws_bin", key=lambda s: s.str.extract(r"([\d.]+)")[0].astype(float))
        fig = px.bar(t, x="ws_bin", y="mean", template=TEMPLATE, title="Mean NO₂ by wind-speed band",
                     labels={"ws_bin": "wind speed (m/s)", "mean": "NO₂ µg/m³"})
        f = (f"Spearman ρ(NO₂, wind speed) = {d['no2'].corr(d['ws'], method='spearman'):.2f}; "
             f"mean NO₂ {t['mean'].iloc[0]:.1f} in the calmest band vs {t['mean'].iloc[-1]:.1f} in the windiest.")
        out.append(Result("B7", "NO₂ vs wind speed", q, t, fig, f))
    else:
        out.append(_missing("B7", "NO₂ vs wind speed", q, "modelled wind speed"))

    # B8 – O3 vs temperature
    q = "Is ozone higher on warmer days?"
    if {"o3_mean", "temp_mean"} <= set(daily.columns) and daily["temp_mean"].notna().sum() > 30:
        d = daily[["o3_max8h", "temp_mean", "site_name"]].dropna()
        rho = d["o3_max8h"].corr(d["temp_mean"], method="spearman")
        t = pd.DataFrame({"metric": ["site-days", "Spearman ρ"], "value": [len(d), round(rho, 3)]})
        fig = px.scatter(d, x="temp_mean", y="o3_max8h", opacity=.4, template=TEMPLATE,
                         title="Daily max 8-h O₃ vs daily mean temperature",
                         labels={"temp_mean": "°C (modelled)", "o3_max8h": "O₃ µg/m³"})
        out.append(Result("B8", "O₃ vs temperature", q, t, fig,
                          f"Spearman ρ = {rho:.2f} between daily max 8-h ozone and temperature ({len(d):,} site-days)."))
    else:
        out.append(_missing("B8", "O₃ vs temperature", q, "modelled temperature"))

    # B9 – NO2 by site
    q = "Which locations record the highest NO₂?"
    if "no2" in hourly:
        t = (hourly.groupby(["site_name", "location_type"])["no2"].agg(["mean", "count"])
             .dropna().sort_values("mean", ascending=False).reset_index())
        fig = px.bar(t, x="mean", y="site_name", color="location_type", orientation="h", template=TEMPLATE,
                     title="Mean NO₂ by monitoring site", labels={"mean": "µg/m³", "site_name": ""},
                     height=max(400, 28 * len(t)))
        fig.update_yaxes(categoryorder="total ascending")
        f = (f"{t.iloc[0].site_name} has the highest mean ({t.iloc[0]['mean']:.1f} µg/m³), "
             f"{t.iloc[0]['mean'] / t.iloc[-1]['mean']:.1f}× the lowest ({t.iloc[-1].site_name}).")
        out.append(Result("B9", "NO₂ by site", q, t, fig, f))
    else:
        out.append(_missing("B9", "NO₂ by site", q, "NO₂"))

    # B10 – PM2.5 by season
    q = "How does daily PM2.5 vary by season?"
    if "pm25_mean" in daily:
        d = daily.dropna(subset=["pm25_mean"])
        t = d.groupby("season", observed=True)["pm25_mean"].describe()[["count", "mean", "50%", "max"]].reset_index()
        fig = px.box(d, x="season", y="pm25_mean", template=TEMPLATE, category_orders={"season": SEASON_ORDER},
                     title="Daily-mean PM2.5 by season", labels={"pm25_mean": "µg/m³"})
        f = f"Highest seasonal mean: {t.loc[t['mean'].idxmax(), 'season']} ({t['mean'].max():.1f} µg/m³); lowest: {t.loc[t['mean'].idxmin(), 'season']} ({t['mean'].min():.1f})."
        out.append(Result("B10", "PM2.5 by season", q, t, fig, f))
    else:
        out.append(_missing("B10", "PM2.5 by season", q, "PM2.5"))
    return out


# ==========================================================================
# Multivariate (10)
# ==========================================================================
def _heat(t, title, zlabel, **kw):
    fig = px.imshow(t, aspect="auto", template=TEMPLATE, title=title, color_continuous_scale="YlOrRd",
                    labels={"color": zlabel}, **kw)
    return fig


def multivariate(hourly: pd.DataFrame, daily: pd.DataFrame) -> list[Result]:
    out = []
    pols = pollutants_in(hourly)
    met = [m for m in ("ws", "temp") if m in hourly and hourly[m].notna().sum() > 100]

    # M1 – correlation matrix
    q = "Which pollutants (and weather variables) rise and fall together?"
    cols = pols + met
    corr = hourly[cols].corr(method="spearman").round(2)
    labels = [name(c) if c in C.POLLUTANTS else C.MET_VARIABLES[c][0] for c in cols]
    corr.index = corr.columns = labels
    fig = px.imshow(corr, text_auto=True, zmin=-1, zmax=1, color_continuous_scale="RdBu_r",
                    template=TEMPLATE, title="Spearman correlation (hourly)")
    pairs = corr.where(np.triu(np.ones(corr.shape, bool), 1)).stack().dropna().sort_values()
    f = (f"Strongest positive pair: {pairs.index[-1][0]} & {pairs.index[-1][1]} (ρ = {pairs.iloc[-1]:.2f}); "
         f"strongest negative: {pairs.index[0][0]} & {pairs.index[0][1]} (ρ = {pairs.iloc[0]:.2f}).") if len(pairs) else ""
    out.append(Result("M1", "Correlation matrix", q, corr.reset_index(names="variable"), fig, f))

    # M2 – site × month NO2
    q = "How does NO₂ vary across both location and month?"
    if "no2" in hourly:
        t = hourly.pivot_table(index="site_name", columns="year_month", values="no2", aggfunc="mean").round(1)
        out.append(Result("M2", "Site × month NO₂", q, t.reset_index(),
                          _heat(t, "Mean NO₂ by site and month", "µg/m³"),
                          f"Highest site-month: {t.stack().idxmax()[0]} in {t.stack().idxmax()[1]} ({t.stack().max():.1f} µg/m³)."))

    # M3 – site × hour NO2
    q = "Do all sites share the same daily NO₂ cycle?"
    if "no2" in hourly:
        t = hourly.pivot_table(index="site_name", columns="hour", values="no2", aggfunc="mean").round(1)
        peak = t.idxmax(axis=1)
        out.append(Result("M3", "Site × hour NO₂", q, t.reset_index(),
                          _heat(t, "Mean NO₂ by site and hour (UK time)", "µg/m³"),
                          "Peak hour by site: " + "; ".join(f"{s}: {h:02d}:00" for s, h in peak.items()) + "."))

    # M4 – site × season × pollutant
    q = "Which sites are worst in which season, for each pollutant?"
    sel = [p for p in ("pm25", "no2", "o3") if p in pols]
    if sel:
        t = hourly.groupby(["site_name", "season"], observed=True)[sel].mean().round(1).reset_index()
        tl = t.melt(id_vars=["site_name", "season"], var_name="pollutant")
        tl["pollutant"] = tl["pollutant"].map(name)
        fig = px.bar(tl, x="site_name", y="value", color="season", facet_row="pollutant", barmode="group",
                     template=TEMPLATE, title="Seasonal mean by site and pollutant",
                     category_orders={"season": SEASON_ORDER}, height=300 * len(sel))
        fig.update_yaxes(matches=None)
        worst = tl.loc[tl.groupby("pollutant")["value"].idxmax()]
        f = "Worst site-season: " + "; ".join(f"{r.pollutant}: {r.site_name} in {r.season} ({r.value:.1f})"
                                              for r in worst.itertuples()) + "."
        out.append(Result("M4", "Site × season × pollutant", q, t, fig, f))

    # M5 – day of week × hour NO2
    q = "When in the week is NO₂ highest?"
    if "no2" in hourly:
        t = hourly.pivot_table(index="day_of_week", columns="hour", values="no2", aggfunc="mean",
                               observed=True).reindex(DAY_ORDER).round(1)
        mx = t.stack().idxmax()
        out.append(Result("M5", "Day-of-week × hour NO₂", q, t.reset_index(),
                          _heat(t, "Mean NO₂ by weekday and hour", "µg/m³"),
                          f"Highest weekly slot: {mx[0]} {mx[1]:02d}:00 ({t.stack().max():.1f} µg/m³)."))

    # M6 – site × pollutant standardised profile
    q = "How does each site's pollution profile compare across all pollutants?"
    if len(pols) >= 2:
        m = hourly.groupby("site_name")[pols].mean()
        z = ((m - m.mean()) / m.std(ddof=0)).round(2)
        z.columns = [name(c) for c in z.columns]
        out.append(Result("M6", "Site pollution profile (z-scores)", q, z.reset_index(),
                          px.imshow(z, text_auto=True, color_continuous_scale="RdBu_r", zmin=-2.5, zmax=2.5,
                                    aspect="auto", template=TEMPLATE,
                                    title="Site means standardised across sites (z-score)"),
                          "Positive z = above the cross-site average for that pollutant; "
                          f"site with highest average z: {z.mean(axis=1).idxmax()}."))

    # M7 – PCA of daily means
    q = "Can the daily pollution mix be summarised by a few underlying components?"
    dcols = [f"{p}_mean" for p in pols if f"{p}_mean" in daily and daily[f"{p}_mean"].notna().mean() > .3]
    X = daily[dcols].dropna()
    if len(dcols) >= 3 and len(X) > 50:
        Z = (X - X.mean()) / X.std(ddof=0)
        U, S, Vt = np.linalg.svd(Z.to_numpy(), full_matrices=False)
        ev = S ** 2 / (S ** 2).sum()
        load = pd.DataFrame(Vt.T[:, :3], index=[name(c[:-5]) for c in dcols],
                            columns=[f"PC{i + 1}" for i in range(min(3, len(dcols)))]).round(3)
        fig = px.bar(x=[f"PC{i + 1}" for i in range(len(ev))], y=ev * 100, template=TEMPLATE,
                     title="PCA of daily pollutant means – variance explained",
                     labels={"x": "component", "y": "% variance"})
        f = (f"PC1 explains {ev[0] * 100:.1f} % of variance across {len(X):,} complete site-days; "
             f"largest PC1 loading: {load['PC1'].abs().idxmax()}.")
        out.append(Result("M7", "PCA of daily pollutant mix", q, load.reset_index(names="pollutant"), fig, f))
    else:
        out.append(_missing("M7", "PCA of daily pollutant mix", q, "≥ 3 pollutants with overlapping days"))

    # M8 – wind × hour × NO2
    q = "How do wind speed and time of day combine to drive NO₂?"
    if {"no2", "ws"} <= set(hourly) and "ws" in met:
        d = hourly[["no2", "ws", "hour"]].dropna()
        d["ws_band"] = pd.cut(d["ws"], [0, 2, 4, 6, 10, 75], include_lowest=True,
                              labels=["0–2", "2–4", "4–6", "6–10", ">10"])
        t = d.pivot_table(index="ws_band", columns="hour", values="no2", aggfunc="mean", observed=True).round(1)
        out.append(Result("M8", "Wind × hour × NO₂", q, t.reset_index(),
                          _heat(t, "Mean NO₂ by wind-speed band (m/s) and hour", "µg/m³"),
                          f"Highest cell: wind {t.stack().idxmax()[0]} m/s at {t.stack().idxmax()[1]:02d}:00 ({t.stack().max():.1f} µg/m³)."))
    else:
        out.append(_missing("M8", "Wind × hour × NO₂", q, "modelled wind speed"))

    # M9 – environment × season × pollutant
    q = "Does the gap between traffic and background sites change with the season?"
    if sel and hourly["location_type"].notna().any():
        t = hourly.groupby(["location_type", "season"], observed=True)[sel].mean().round(1).reset_index()
        tl = t.melt(id_vars=["location_type", "season"], var_name="pollutant")
        tl["pollutant"] = tl["pollutant"].map(name)
        fig = px.line(tl, x="season", y="value", color="location_type", facet_col="pollutant", markers=True,
                      template=TEMPLATE, category_orders={"season": SEASON_ORDER},
                      title="Seasonal mean by site environment")
        fig.update_yaxes(matches=None)
        out.append(Result("M9", "Environment × season × pollutant", q, t, fig,
                          "See table: compare environments within each season."))

    # M10 – temperature × season × O3
    q = "Is the ozone–temperature relationship the same in every season?"
    if {"o3_max8h", "temp_mean"} <= set(daily) and daily["temp_mean"].notna().sum() > 30:
        d = daily[["o3_max8h", "temp_mean", "season"]].dropna()
        d["temp_band"] = pd.cut(d["temp_mean"], [-40, 0, 5, 10, 15, 20, 50],
                                labels=["<0", "0–5", "5–10", "10–15", "15–20", ">20"])
        t = d.pivot_table(index="season", columns="temp_band", values="o3_max8h",
                          aggfunc="mean", observed=True).reindex(SEASON_ORDER).round(1)
        out.append(Result("M10", "Temperature × season × O₃", q, t.reset_index(),
                          _heat(t, "Daily max 8-h O₃ by season and temperature band (°C)", "µg/m³"),
                          f"Highest cell: {t.stack().idxmax()[0]}, {t.stack().idxmax()[1]} °C ({t.stack().max():.1f} µg/m³)."))
    else:
        out.append(_missing("M10", "Temperature × season × O₃", q, "modelled temperature"))
    return out


# ==========================================================================
# Time series
# ==========================================================================
def monthly_series(daily: pd.DataFrame, p: str, min_days: int = 23) -> pd.DataFrame:
    """Monthly means from valid daily means; months with < 23 valid days
    (~75 % of a month) are excluded."""
    col = f"{p}_mean"
    if col not in daily:
        return pd.DataFrame()
    g = daily.groupby(["site_name", "year_month"])[col].agg(["mean", "count"]).reset_index()
    g = g[g["count"] >= min_days]
    g["month_start"] = pd.to_datetime(g["year_month"] + "-01")
    return g


def theil_sen(x: np.ndarray, y: np.ndarray) -> float:
    i, j = np.triu_indices(len(x), 1)
    dx = x[j] - x[i]
    ok = dx != 0
    return float(np.median((y[j] - y[i])[ok] / dx[ok])) if ok.any() else np.nan


def trends(daily: pd.DataFrame, min_months: int = 18) -> Result:
    """Theil–Sen slope of de-seasonalised monthly means per site × pollutant."""
    q = "Are there identifiable trends over the study window?"
    rows = []
    for p in pollutants_in(daily.rename(columns=lambda c: c.replace("_mean", ""))):
        m = monthly_series(daily, p)
        if m.empty:
            continue
        m["cal_month"] = m["month_start"].dt.month
        m["anom"] = m["mean"] - m.groupby(["site_name", "cal_month"])["mean"].transform("mean")
        for site, g in m.groupby("site_name"):
            if len(g) < min_months:
                continue
            x = (g["month_start"] - g["month_start"].min()).dt.days.to_numpy() / 365.25
            slope = theil_sen(x, g["anom"].to_numpy())
            rows.append({"site_name": site, "pollutant": name(p), "months": len(g),
                         "slope_per_year": round(slope, 2),
                         "pct_of_mean_per_year": round(100 * slope / g["mean"].mean(), 1)})
    t = pd.DataFrame(rows)
    if t.empty:
        return Result("TS1", "Trend analysis", q,
                      finding=f"Not computed: no site-pollutant series has ≥ {min_months} valid months.")
    fig = px.bar(t, x="pct_of_mean_per_year", y="site_name", color="pollutant", barmode="group",
                 orientation="h", template=TEMPLATE, height=max(400, 30 * t["site_name"].nunique()),
                 title="Indicative trend (Theil–Sen, de-seasonalised), % of mean per year")
    down = (t["slope_per_year"] < 0).mean() * 100
    f = (f"{down:.0f} % of {len(t)} site-pollutant series show a downward slope. With only a few years of "
         "data these slopes are indicative, not statistically robust trends.")
    return Result("TS1", "Trend analysis", q, t, fig, f)


def daily_trend_fig(daily: pd.DataFrame, p: str, sites: list[str] | None = None) -> go.Figure:
    col = f"{p}_mean"
    d = daily.dropna(subset=[col]).copy()
    if sites:
        d = d[d["site_name"].isin(sites)]
    d = d.sort_values("date_local")
    d["30-day rolling mean"] = d.groupby("site_name")[col].transform(lambda s: s.rolling(30, min_periods=20).mean())
    fig = px.line(d, x="date_local", y="30-day rolling mean", color="site_name", template=TEMPLATE,
                  title=f"{name(p)} – 30-day rolling mean of daily means", labels={"date_local": ""})
    fig.update_yaxes(title=unit(p))
    if p in C.WHO_2021 and "24h" in C.WHO_2021[p]:
        fig.add_hline(y=C.WHO_2021[p]["24h"], line_dash="dot", annotation_text="WHO 24-h guideline")
    return fig


# ==========================================================================
# Hotspots
# ==========================================================================
def hotspots(hourly: pd.DataFrame, daily: pd.DataFrame) -> Result:
    """Composite hotspot score: mean percentile rank of each site across the
    primary (locally emitted) pollutants PM2.5, PM10 and NO₂. Ozone is
    excluded because it is a regional secondary pollutant that is typically
    lower where NO₂ is high."""
    q = "Which monitoring stations are pollution hotspots, and how often are they in a high-pollution state?"
    prim = [p for p in ("pm25", "pm10", "no2") if p in hourly]
    if not prim:
        return Result("H1", "Hotspots", q, finding="Not computed: no primary pollutants present.")
    site = hourly.groupby(["site_code", "site_name", "city", "location_type", "latitude", "longitude"],
                          dropna=False)[prim].mean()
    ranks = site.rank(pct=True)
    site["hotspot_score"] = (100 * ranks.mean(axis=1)).round(1)
    for p in prim:
        b = f"{p}_daqi_band"
        if b in daily:
            pct = daily.groupby("site_code")[b].apply(lambda s: 100 * s.isin(["Moderate", "High", "Very High"]).sum()
                                                       / max(s.notna().sum(), 1))
            site[f"{p}_pct_days_moderate_plus"] = site.index.get_level_values("site_code").map(pct).round(2)
        w = f"{p}_who_exceed"
        if w in daily:
            n = daily.groupby("site_code")[w].sum()
            site[f"{p}_days_over_who24h"] = site.index.get_level_values("site_code").map(n)
    t = site.reset_index().sort_values("hotspot_score", ascending=False)
    t[prim] = t[prim].round(1)
    fig = px.scatter_map(t.dropna(subset=["latitude", "longitude"]), lat="latitude", lon="longitude",
                         size="hotspot_score", color="hotspot_score", hover_name="site_name",
                         hover_data={p: True for p in prim}, color_continuous_scale="YlOrRd",
                         size_max=28, zoom=4.6, center={"lat": 54.3, "lon": -2.5},
                         map_style="open-street-map", title="Pollution hotspot score by site", height=650)
    top = t.head(3)
    f = "Top hotspots (composite of " + ", ".join(name(p) for p in prim) + "): " + "; ".join(
        f"{r.site_name} ({r.hotspot_score:.0f}/100)" for r in top.itertuples()) + "."
    return Result("H1", "Pollution hotspots", q, t, fig, f)


# ==========================================================================
# Anomalies
# ==========================================================================
def anomalies(daily: pd.DataFrame) -> Result:
    """Robust z-score of each daily mean against a centred 30-day rolling
    median and MAD (Iglewicz & Hoaglin modified z, threshold 3.5)."""
    q = "What unusual pollution spikes can be identified?"
    rows = []
    for p in pollutants_in(daily.rename(columns=lambda c: c.replace("_mean", ""))):
        col = f"{p}_mean"
        for site, g in daily.sort_values("date_local").groupby("site_name"):
            s = g.set_index("date_local")[col]
            if s.notna().sum() < 60:
                continue
            med = s.rolling(C.ANOMALY_WINDOW_DAYS, center=True, min_periods=15).median()
            mad = (s - med).abs().rolling(C.ANOMALY_WINDOW_DAYS, center=True, min_periods=15).median()
            z = 0.6745 * (s - med) / mad.replace(0, np.nan)
            hit = z[z > C.ANOMALY_Z]
            for d, zz in hit.items():
                rows.append({"site_name": site, "date": d, "pollutant": name(p), "daily_mean": round(s[d], 1),
                             "rolling_median": round(med[d], 1), "robust_z": round(zz, 1), "unit": unit(p)})
    t = pd.DataFrame(rows)
    if t.empty:
        return Result("A1", "Anomalies", q, finding="No spikes exceeded the robust z threshold.")
    t = t.sort_values("robust_z", ascending=False)
    counts = t.groupby(["site_name", "pollutant"]).size().rename("spike_days").reset_index()
    fig = px.scatter(t, x="date", y="daily_mean", color="pollutant", size="robust_z", hover_name="site_name",
                     template=TEMPLATE, title="Detected daily spikes (robust z > 3.5)")
    shared = t.groupby(["date", "pollutant"])["site_name"].nunique().sort_values(ascending=False)
    f = (f"{len(t)} spike site-days detected. Most frequent: {counts.sort_values('spike_days').iloc[-1].site_name} "
         f"({counts.sort_values('spike_days').iloc[-1].pollutant}). ")
    if len(shared) and shared.iloc[0] >= 3:
        f += (f"On {shared.index[0][0]:%Y-%m-%d} {shared.iloc[0]} sites spiked together for "
              f"{shared.index[0][1]} – a regional episode rather than a local one.")
    return Result("A1", "Anomaly detection", q, t, fig, f)


# ==========================================================================
# Latest readings
# ==========================================================================
def latest_readings(hourly: pd.DataFrame) -> pd.DataFrame:
    rows = []
    now = pd.Timestamp.now(tz="UTC")
    for (code, site), g in hourly.groupby(["site_code", "site_name"]):
        for p in pollutants_in(g):
            s = g.dropna(subset=[p])
            if s.empty:
                continue
            r = s.iloc[-1]
            band = r.get(f"{p}_daqi_band")
            rows.append({"site_name": site, "pollutant": name(p), "value": round(r[p], 1), "unit": unit(p),
                         "hour_beginning_uk": r["datetime_local"].strftime("%Y-%m-%d %H:%M"),
                         "hours_old": round((now - r["date"]).total_seconds() / 3600, 1),
                         "daqi_band": band if isinstance(band, str) else "—"})
    return pd.DataFrame(rows)
