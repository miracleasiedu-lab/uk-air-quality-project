"""
Central configuration for the UK Air Quality Analytics project.

Every URL, unit and threshold below is documented with its source in
docs/methodology.md. Nothing here is a result: results are only ever
computed from the files downloaded by src/extract.py.
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "reports"
FIGURES = REPORTS / "figures"

# --------------------------------------------------------------------------
# DEFRA UK-AIR data services (Automatic Urban and Rural Network, AURN)
# --------------------------------------------------------------------------
# Primary source: hourly site-year files that Ricardo Energy & Environment
# publishes on UK-AIR on behalf of Defra for the openair project.
# Hour-BEGINNING timestamps, GMT/UTC.
DEFRA_RDATA_URL = "https://uk-air.defra.gov.uk/openair/R_data/{site}_{year}.RData"
DEFRA_METADATA_URL = "https://uk-air.defra.gov.uk/openair/R_data/AURN_metadata.RData"

# Fallback source: UK-AIR "pre-formatted files" (one CSV per site and year,
# updated daily). Hour-ENDING timestamps (the parser converts them).
DEFRA_CSV_URL = "https://uk-air.defra.gov.uk/datastore/data_files/site_data/{site}_{year}.csv"

HTTP_TIMEOUT = 60
HTTP_RETRIES = 3
USER_AGENT = "uk-air-quality-portfolio/1.0 (educational analytics project)"

ATTRIBUTION = (
    "© Crown copyright Defra via uk-air.defra.gov.uk, "
    "licensed under the Open Government Licence (OGL)."
)

# --------------------------------------------------------------------------
# Study design
# --------------------------------------------------------------------------
# At least 12 months of history: by default the two previous full calendar
# years plus the current year to date (the most recent available readings).
CURRENT_YEAR = date.today().year
YEARS = [CURRENT_YEAR - 2, CURRENT_YEAR - 1, CURRENT_YEAR]

# Candidate AURN sites: London plus major UK cities.
# These codes are CANDIDATES only. src/extract.py checks every code against
# the live DEFRA metadata and drops (and logs) any that are not found or
# that have no data in the study window. The site name, city, site type and
# coordinates used in the analysis always come from DEFRA metadata, never
# from this dictionary. Use `python -m src.extract --discover <city>` to list
# the real site codes for any town.
CANDIDATE_SITES = {
    "MY1": "London",       # London Marylebone Road
    "KC1": "London",       # London N. Kensington
    "CLL2": "London",      # London Bloomsbury
    "MAN3": "Manchester",
    "BMLD": "Birmingham",
    "LEED": "Leeds",
    "NEWC": "Newcastle",
    "BRS8": "Bristol",
    "LVP": "Liverpool",
    "SHDG": "Sheffield",
    "NOTT": "Nottingham",
    "CARD": "Cardiff",
    "GLA4": "Glasgow",
    "ED3": "Edinburgh",
    "BEL2": "Belfast",
}

# --------------------------------------------------------------------------
# Pollutants and units
# --------------------------------------------------------------------------
# Units as documented by openair/Defra for these files: gases are in mass
# units (µg/m³) except CO (mg/m³); PM is µg/m³ (gravimetric equivalent).
POLLUTANTS = {
    # column  : (display name,            unit,     category)
    "pm25": ("PM2.5", "µg/m³", "Particulate"),
    "pm10": ("PM10", "µg/m³", "Particulate"),
    "no2": ("Nitrogen dioxide (NO₂)", "µg/m³", "Gaseous – combustion"),
    "o3": ("Ozone (O₃)", "µg/m³", "Gaseous – secondary"),
    "so2": ("Sulphur dioxide (SO₂)", "µg/m³", "Gaseous – combustion"),
    "co": ("Carbon monoxide (CO)", "mg/m³", "Gaseous – combustion"),
}
POLLUTANT_ORDER = list(POLLUTANTS)

# Modelled meteorology that DEFRA/openair files carry when available.
MET_VARIABLES = {
    "ws": ("Wind speed (modelled)", "m/s"),
    "wd": ("Wind direction (modelled)", "degrees"),
    "temp": ("Air temperature (modelled)", "°C"),
}

# Map raw DEFRA/openair column names (any case) to the project's names.
RAW_COLUMN_MAP = {
    "pm2.5": "pm25", "pm25": "pm25",
    "pm10": "pm10",
    "no2": "no2",
    "o3": "o3",
    "so2": "so2",
    "co": "co",
    "ws": "ws", "wd": "wd", "temp": "temp", "air_temp": "temp",
}

# Physical-plausibility caps (data-cleaning guard rails, NOT health limits).
# Values above these are treated as instrument/transfer errors.
PLAUSIBILITY_MAX = {
    "pm25": 1000, "pm10": 2000, "no2": 2000, "o3": 1000, "so2": 3000, "co": 100,
}

# --------------------------------------------------------------------------
# Thresholds
# --------------------------------------------------------------------------
# UK Daily Air Quality Index (DAQI) band lower bounds, µg/m³, with the
# averaging period each pollutant's index uses.
DAQI = {
    "pm25": {"averaging": "24-hour mean", "moderate": 36, "high": 54, "very_high": 71},
    "pm10": {"averaging": "24-hour mean", "moderate": 51, "high": 76, "very_high": 101},
    "no2": {"averaging": "1-hour mean", "moderate": 201, "high": 401, "very_high": 601},
    "o3": {"averaging": "8-hour running mean", "moderate": 101, "high": 161, "very_high": 241},
    # DAQI SO2 uses 15-minute means; these files are hourly, so the SO2 band
    # applied here is an approximation and is labelled as such.
    "so2": {"averaging": "1-hour mean (DAQI uses 15-min)", "moderate": 267, "high": 533, "very_high": 1065},
}
DAQI_BANDS = ["Low", "Moderate", "High", "Very High"]

# WHO 2021 Air Quality Guidelines (µg/m³) – used as a stricter health
# benchmark alongside the DAQI.
WHO_2021 = {
    "pm25": {"annual": 5, "24h": 15},
    "pm10": {"annual": 15, "24h": 45},
    "no2": {"annual": 10, "24h": 25},
    "o3": {"8h": 100},
}

# UK legal annual-mean limits (µg/m³) for context in the annual comparison.
UK_ANNUAL_LIMIT = {"pm25": 20, "pm10": 40, "no2": 40}

# Data-capture rules
DAILY_MIN_HOURS = 18          # a daily mean needs ≥ 75 % of hours
EIGHT_HOUR_MIN = 6            # an 8-hour running mean needs ≥ 75 % of hours
ANNUAL_MIN_CAPTURE = 0.90     # annual statistics flagged below 90 % capture

# Anomaly detection: robust (median/MAD) z-score on daily means.
ANOMALY_WINDOW_DAYS = 30
ANOMALY_Z = 3.5

# Local time used for hour-of-day / weekday features (traffic follows the
# local clock, which shifts with British Summer Time).
LOCAL_TZ = "Europe/London"
