"""
Raw-data validation and data-quality assessment.

validate_raw()   – structural checks that must pass before cleaning.
assess_quality() – per site × pollutant completeness and validity profile.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src import config as C


def validate_raw(raw: pd.DataFrame, meta: pd.DataFrame) -> pd.DataFrame:
    """Return a table of named checks with pass/fail and detail."""
    checks = []

    def add(name, passed, detail):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    required = {"date", "site_code"}
    add("Required columns present", required <= set(raw.columns),
        f"missing: {sorted(required - set(raw.columns)) or 'none'}")
    pols = [p for p in C.POLLUTANTS if p in raw.columns]
    add("At least one target pollutant present", bool(pols), f"found: {pols}")
    add("Timestamps are timezone-aware UTC",
        isinstance(raw["date"].dtype, pd.DatetimeTZDtype), str(raw["date"].dtype))
    add("No null timestamps", raw["date"].notna().all(), f"nulls: {int(raw['date'].isna().sum())}")
    add("No null site codes", raw["site_code"].notna().all(), "")
    non_numeric = [p for p in pols if not pd.api.types.is_numeric_dtype(raw[p])]
    add("Pollutant columns numeric", not non_numeric, f"non-numeric: {non_numeric or 'none'}")
    unknown = sorted(set(raw["site_code"]) - set(meta["site_code"]))
    add("All sites exist in DEFRA metadata", not unknown, f"unknown: {unknown or 'none'}")
    span_days = (raw["date"].max() - raw["date"].min()).days
    add("Coverage of at least 12 months", span_days >= 365,
        f"{raw['date'].min():%Y-%m-%d} → {raw['date'].max():%Y-%m-%d} ({span_days} days)")
    dups = int(raw.duplicated(["site_code", "date"]).sum())
    add("No duplicate site-hour records", dups == 0, f"duplicates: {dups}")
    on_hour = (raw["date"].dt.minute == 0).all()
    add("Timestamps on the hour", on_hour, "")
    return pd.DataFrame(checks)


def _longest_gap_hours(s: pd.Series) -> int:
    """Longest run of consecutive missing hours in an hourly series."""
    missing = s.isna().to_numpy()
    if not missing.any():
        return 0
    edges = np.diff(np.concatenate(([0], missing.astype(int), [0])))
    starts, ends = np.where(edges == 1)[0], np.where(edges == -1)[0]
    return int((ends - starts).max())


def assess_quality(raw: pd.DataFrame) -> pd.DataFrame:
    """Completeness / validity profile per site × pollutant.

    Expected hours run from the site's first to last timestamp, so a site
    that opened mid-window is not penalised for hours before it existed.
    """
    rows = []
    for site, g in raw.groupby("site_code"):
        g = g.drop_duplicates("date").set_index("date").sort_index()
        full = pd.date_range(g.index.min(), g.index.max(), freq="h")
        g = g.reindex(full)
        for p in C.POLLUTANTS:
            if p not in g.columns:
                continue
            s = g[p]
            n_valid = int(s.notna().sum())
            if n_valid == 0:
                continue
            rows.append({
                "site_code": site,
                "pollutant": p,
                "expected_hours": len(full),
                "valid_hours": n_valid,
                "capture_pct": round(100 * n_valid / len(full), 1),
                "negative_values": int((s < 0).sum()),
                "above_plausibility_cap": int((s > C.PLAUSIBILITY_MAX[p]).sum()),
                "longest_gap_hours": _longest_gap_hours(s),
                "first_valid": s.first_valid_index(),
                "last_valid": s.last_valid_index(),
            })
    dq = pd.DataFrame(rows)
    if len(dq):
        dq["meets_annual_capture"] = dq["capture_pct"] >= 100 * C.ANNUAL_MIN_CAPTURE
    return dq
