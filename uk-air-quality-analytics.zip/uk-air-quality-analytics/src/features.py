"""
Feature engineering.

build_hourly() – adds calendar, season, rolling-mean, DAQI and
                 high-pollution features to the clean hourly panel (wide).
to_long()      – one row per site × hour × pollutant (tidy).
build_daily()  – daily means / maxima with the 18-hour capture rule.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src import config as C

SEASONS = {12: "Winter", 1: "Winter", 2: "Winter", 3: "Spring", 4: "Spring", 5: "Spring",
           6: "Summer", 7: "Summer", 8: "Summer", 9: "Autumn", 10: "Autumn", 11: "Autumn"}
SEASON_ORDER = ["Winter", "Spring", "Summer", "Autumn"]
DAY_ORDER = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTH_ORDER = ["January", "February", "March", "April", "May", "June", "July",
               "August", "September", "October", "November", "December"]

# Which metric each pollutant's DAQI band is assessed on (hourly panel)
DAQI_METRIC = {"pm25": "pm25_24h", "pm10": "pm10_24h", "no2": "no2", "o3": "o3_8h", "so2": "so2"}


def pollutants_in(df: pd.DataFrame) -> list[str]:
    return [p for p in C.POLLUTANT_ORDER if p in df.columns]


def daqi_band(values: pd.Series, pollutant: str) -> pd.Series:
    t = C.DAQI[pollutant]
    bins = [-np.inf, t["moderate"], t["high"], t["very_high"], np.inf]
    return pd.cut(values, bins=bins, labels=C.DAQI_BANDS, right=False)


def build_hourly(clean: pd.DataFrame) -> pd.DataFrame:
    df = clean.copy()
    pols = pollutants_in(df)

    # Calendar features in UK local time
    local = df["date"].dt.tz_convert(C.LOCAL_TZ)
    df["datetime_local"] = local
    df["date_local"] = local.dt.tz_localize(None).dt.normalize()
    df["year"] = local.dt.year
    df["month"] = local.dt.month
    df["month_name"] = pd.Categorical(local.dt.month_name(), MONTH_ORDER, ordered=True)
    df["year_month"] = local.dt.strftime("%Y-%m")
    df["day"] = local.dt.day
    df["day_of_week"] = pd.Categorical(local.dt.day_name(), DAY_ORDER, ordered=True)
    df["hour"] = local.dt.hour
    df["is_weekend"] = local.dt.dayofweek >= 5
    df["day_type"] = np.where(df["is_weekend"], "Weekend", "Weekday")
    df["season"] = pd.Categorical(df["month"].map(SEASONS), SEASON_ORDER, ordered=True)

    # Rolling averages (grid is complete per site, so N rows = N hours)
    g = df.groupby("site_code", group_keys=False)
    for p in pols:
        df[f"{p}_24h"] = g[p].transform(lambda s: s.rolling(24, min_periods=C.DAILY_MIN_HOURS).mean())
        df[f"{p}_7d"] = g[p].transform(lambda s: s.rolling(24 * 7, min_periods=24 * 5).mean())
    if "o3" in pols:
        df["o3_8h"] = g["o3"].transform(lambda s: s.rolling(8, min_periods=C.EIGHT_HOUR_MIN).mean())

    # DAQI bands and high-pollution indicators
    flags = []
    for p in pols:
        if p not in C.DAQI:
            continue
        band = daqi_band(df[DAQI_METRIC[p]], p)
        df[f"{p}_daqi_band"] = band
        df[f"{p}_high"] = band.isin(["Moderate", "High", "Very High"]).astype("float64").where(band.notna())
        flags.append(f"{p}_high")
    if flags:
        f = df[flags].astype("float")
        df["any_daqi_assessed"] = f.notna().any(axis=1)
        # 1.0 = high, 0.0 = not high, NaN = no DAQI pollutant assessable that hour
        df["high_pollution"] = (f == 1).any(axis=1).astype("float64").where(df["any_daqi_assessed"])
    return df


def to_long(hourly: pd.DataFrame) -> pd.DataFrame:
    pols = pollutants_in(hourly)
    id_cols = ["site_code", "site_name", "city", "location_type", "latitude", "longitude",
               "date", "date_local", "year", "month", "month_name", "year_month",
               "day_of_week", "hour", "day_type", "season"]
    long = hourly.melt(id_vars=[c for c in id_cols if c in hourly],
                       value_vars=pols, var_name="pollutant", value_name="value")
    long = long.dropna(subset=["value"])
    long["pollutant_name"] = long["pollutant"].map(lambda p: C.POLLUTANTS[p][0])
    long["unit"] = long["pollutant"].map(lambda p: C.POLLUTANTS[p][1])
    long["pollutant_category"] = long["pollutant"].map(lambda p: C.POLLUTANTS[p][2])
    return long.reset_index(drop=True)


def build_daily(hourly: pd.DataFrame) -> pd.DataFrame:
    """Daily statistics per site; a daily mean needs ≥ 18 valid hours."""
    pols = pollutants_in(hourly)
    keys = ["site_code", "site_name", "city", "location_type", "date_local"]
    agg = {}
    for p in pols:
        agg[f"{p}_mean"] = (p, "mean")
        agg[f"{p}_max"] = (p, "max")
        agg[f"{p}_n"] = (p, "count")
    if "o3_8h" in hourly:
        agg["o3_max8h"] = ("o3_8h", "max")
    for m in ("ws", "temp"):
        if m in hourly:
            agg[f"{m}_mean"] = (m, "mean")
    daily = hourly.groupby(keys, observed=True, dropna=False).agg(**agg).reset_index()
    for p in pols:
        short = daily[f"{p}_n"] < C.DAILY_MIN_HOURS
        daily.loc[short, [f"{p}_mean", f"{p}_max"]] = np.nan
    if "o3_max8h" in daily:
        daily.loc[daily["o3_n"] < C.DAILY_MIN_HOURS, "o3_max8h"] = np.nan

    d = pd.to_datetime(daily["date_local"])
    daily["year"], daily["month"] = d.dt.year, d.dt.month
    daily["year_month"] = d.dt.strftime("%Y-%m")
    daily["day_of_week"] = pd.Categorical(d.dt.day_name(), DAY_ORDER, ordered=True)
    daily["day_type"] = np.where(d.dt.dayofweek >= 5, "Weekend", "Weekday")
    daily["season"] = pd.Categorical(daily["month"].map(SEASONS), SEASON_ORDER, ordered=True)

    # Daily DAQI per pollutant: PM on daily mean, NO2 on max hourly,
    # O3 on max 8-hour running mean (the DAQI conventions).
    metric = {"pm25": "pm25_mean", "pm10": "pm10_mean", "no2": "no2_max",
              "o3": "o3_max8h", "so2": "so2_max"}
    for p in pols:
        if p in metric and metric[p] in daily:
            daily[f"{p}_daqi_band"] = daqi_band(daily[metric[p]], p)
    # WHO 2021 24-hour guideline exceedance days
    for p, lim in C.WHO_2021.items():
        if "24h" in lim and f"{p}_mean" in daily:
            daily[f"{p}_who_exceed"] = (daily[f"{p}_mean"] > lim["24h"]).astype("float64").where(daily[f"{p}_mean"].notna())
    return daily
